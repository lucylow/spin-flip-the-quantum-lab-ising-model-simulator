import { MODEL_ORDER, type ModelId } from './detector'
import type { Geometry, Phase } from './ising'

export interface Submission {
  id: number
  key: string
  model: ModelId
  truth: Phase
  truthReason: string
  pred: Phase
  confidence: number
  fooled: boolean
  novel: boolean
  explanation: string
  spins: Int8Array
  L: number
  geometry: Geometry
}

export type LogKind = 'mission' | 'prediction' | 'ai' | 'sweep' | 'model'

export interface LogEntry {
  id: number
  kind: LogKind
  text: string
  time: string
}

export interface GameState {
  activeMission: string
  completed: string[]
  model: ModelId
  submissions: Submission[]
  lastSubmission: Submission | null
  score: number
  tcError: number | null
  log: LogEntry[]
  nextId: number
}

export const initialGame: GameState = {
  activeMission: 'magnet',
  completed: [],
  model: 'v1',
  submissions: [],
  lastSubmission: null,
  score: 0,
  tcError: null,
  log: [],
  nextId: 1,
}

export type GameAction =
  | { type: 'selectMission'; id: string }
  | { type: 'completeMission'; id: string; title: string }
  | { type: 'submit'; submission: Omit<Submission, 'id' | 'novel' | 'key'> }
  | { type: 'retrain' }
  | { type: 'tcEstimate'; error: number; estimate: number }
  | { type: 'log'; kind: LogKind; text: string }

const now = () =>
  new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })

function withLog(state: GameState, kind: LogKind, text: string): GameState {
  return {
    ...state,
    log: [{ id: state.nextId, kind, text, time: now() }, ...state.log].slice(0, 80),
    nextId: state.nextId + 1,
  }
}

export function weaknessesFor(state: GameState, model: ModelId) {
  return new Set(state.submissions.filter((s) => s.fooled && s.model === model).map((s) => s.key))
    .size
}

export function canRetrain(state: GameState) {
  return state.model !== 'v3' && weaknessesFor(state, state.model) >= 2
}

export function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'selectMission':
      return { ...state, activeMission: action.id }
    case 'completeMission': {
      if (state.completed.includes(action.id)) return state
      const next = { ...state, completed: [...state.completed, action.id], score: state.score + 50 }
      return withLog(next, 'mission', `Mission complete: ${action.title} (+50)`)
    }
    case 'submit': {
      const s = action.submission
      const key = `${s.model}:${s.truth}->${s.pred}`
      const novel = s.fooled && !state.submissions.some((x) => x.key === key && x.fooled)
      const submission: Submission = { ...s, id: state.nextId, key, novel }
      const next = {
        ...state,
        submissions: [submission, ...state.submissions].slice(0, 40),
        lastSubmission: submission,
        score: state.score + (novel ? 100 : 0),
        nextId: state.nextId + 1,
      }
      const text = s.fooled
        ? `Detector ${s.model} fooled: predicted ${s.pred}, physics says ${s.truth}${novel ? ' (+100)' : ' (known weakness)'}`
        : `Detector ${s.model} correct: ${s.pred} (${Math.round(s.confidence * 100)}%)`
      return withLog(next, 'ai', text)
    }
    case 'retrain': {
      if (!canRetrain(state)) return state
      const model = MODEL_ORDER[MODEL_ORDER.indexOf(state.model) + 1]
      return withLog(
        { ...state, model, lastSubmission: null, score: state.score + 150 },
        'model',
        `Detector retrained to ${model} using your adversarial examples (+150)`,
      )
    }
    case 'tcEstimate':
      return withLog(
        {
          ...state,
          tcError: state.tcError === null ? action.error : Math.min(state.tcError, action.error),
        },
        'sweep',
        `Submitted T꜀ estimate ${action.estimate.toFixed(2)} (error ${action.error.toFixed(2)})`,
      )
    case 'log':
      return withLog(state, action.kind, action.text)
  }
}
