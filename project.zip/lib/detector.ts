import { PHASES, type Geometry, type Metrics, type Phase } from './ising'

export type ModelId = 'v1' | 'v2' | 'v3'

export interface DetectorModel {
  id: ModelId
  name: string
  features: string[]
  description: string
  blindSpot: string
  upgradeNote: string
}

export const MODELS: Record<ModelId, DetectorModel> = {
  v1: {
    id: 'v1',
    name: 'Magnetometer Net',
    features: ['|m| net magnetization', '|mₛ| checkerboard order'],
    description:
      'Trained on uniform magnets and perfect checkerboards. It only sees two global averages of the whole sample.',
    blindSpot:
      'It confuses "zero net magnetization" with "disorder". Any ordered state whose averages cancel looks paramagnetic to it.',
    upgradeNote: '',
  },
  v2: {
    id: 'v2',
    name: 'Correlation Net',
    features: ['|m|', '|mₛ|', '⟨sᵢsⱼ⟩ neighbour correlation', 'domain wall density'],
    description:
      'Retrained on your adversarial examples. It now looks at local correlations between neighbours, not just global averages.',
    blindSpot:
      'Local correlations can still average out. Patterns where each spin has as many agreeing as disagreeing neighbours fool it.',
    upgradeNote:
      'Added local neighbour correlations. Two domains are no longer mistaken for disorder.',
  },
  v3: {
    id: 'v3',
    name: 'Structure Factor Net',
    features: [
      '|m|',
      '|mₛ|',
      '⟨sᵢsⱼ⟩',
      'structure factor S(q) peak',
      'unsatisfied bonds given the Hamiltonian',
    ],
    description:
      'Physics-informed: it is given the Fourier structure factor and the Hamiltonian, the same quantities a physicist would compute.',
    blindSpot:
      'Close to thresholds, a single snapshot is ambiguous. Physicists would average over many configurations.',
    upgradeNote:
      'Added the structure factor and frustration features. The model now uses physics, not just pattern statistics.',
  },
}

export const MODEL_ORDER: ModelId[] = ['v1', 'v2', 'v3']

export interface FeatureNote {
  feature: string
  value: string
  pushes: Phase
}

export interface Prediction {
  probs: Record<Phase, number>
  top: Phase
  confidence: number
  notes: FeatureNote[]
}

type Logits = Record<Phase, number>

function emptyLogits(): Logits {
  return {
    Ferromagnetic: 0,
    Antiferromagnetic: 0,
    Paramagnetic: 0,
    Frustrated: 0,
    Critical: 0,
    Unknown: 0,
  }
}

function v1Logits(m: Metrics): Logits {
  const big = Math.max(m.absM, m.absMs)
  return {
    Ferromagnetic: 9 * (m.absM - 0.5),
    Antiferromagnetic: 9 * (m.absMs - 0.5),
    Paramagnetic: 9 * (0.25 - big),
    Frustrated: -3,
    Critical: 3 - 40 * (big - 0.35) ** 2,
    Unknown: -3,
  }
}

function v2Logits(m: Metrics): Logits {
  const c = m.correlation
  const big = Math.max(m.absM, m.absMs)
  return {
    Ferromagnetic: 4 * (m.absM - 0.5) + 10 * (c - 0.55),
    Antiferromagnetic: 4 * (m.absMs - 0.5) + 10 * (-c - 0.55),
    Paramagnetic: 6 * (0.3 - Math.abs(c)) + 2 * (0.3 - big),
    Frustrated: 8 * (-c - 0.2),
    Critical: 2 - 30 * (Math.abs(c) - 0.5) ** 2,
    Unknown: -3,
  }
}

function v3Logits(m: Metrics, geometry: Geometry, J: number): Logits {
  const base = v2Logits(m)
  const l = emptyLogits()
  for (const p of PHASES) l[p] = base[p] * 0.3
  if (geometry === 'triangular' && J < 0 && m.unsatisfied <= 0.42) {
    l.Frustrated += 6
  } else if (m.peak >= 0.5) {
    if (m.peakKind === 'uniform') l.Ferromagnetic += 5
    else if (m.peakKind === 'checkerboard') l.Antiferromagnetic += 5
    else l.Unknown += 5
  } else if (m.peak >= 0.2 && Math.abs(m.correlation) >= 0.4) {
    l.Critical += 4
  } else {
    l.Paramagnetic += 3
  }
  return l
}

function softmax(l: Logits): Record<Phase, number> {
  const max = Math.max(...PHASES.map((p) => l[p]))
  let total = 0
  const out = emptyLogits()
  for (const p of PHASES) {
    out[p] = Math.exp(l[p] - max)
    total += out[p]
  }
  for (const p of PHASES) out[p] /= total
  return out
}

export function predict(model: ModelId, m: Metrics, geometry: Geometry, J: number): Prediction {
  const logits =
    model === 'v1' ? v1Logits(m) : model === 'v2' ? v2Logits(m) : v3Logits(m, geometry, J)
  const probs = softmax(logits)
  let top: Phase = 'Paramagnetic'
  for (const p of PHASES) if (probs[p] > probs[top]) top = p

  const notes: FeatureNote[] = [
    {
      feature: '|m|',
      value: m.absM.toFixed(2),
      pushes: m.absM > 0.5 ? 'Ferromagnetic' : 'Paramagnetic',
    },
    {
      feature: '|mₛ|',
      value: m.absMs.toFixed(2),
      pushes: m.absMs > 0.5 ? 'Antiferromagnetic' : 'Paramagnetic',
    },
  ]
  if (model !== 'v1') {
    notes.push({
      feature: '⟨sᵢsⱼ⟩',
      value: m.correlation.toFixed(2),
      pushes:
        m.correlation > 0.55
          ? 'Ferromagnetic'
          : m.correlation < -0.55
            ? 'Antiferromagnetic'
            : m.correlation < -0.2
              ? 'Frustrated'
              : 'Paramagnetic',
    })
  }
  if (model === 'v3') {
    notes.push({
      feature: 'S(q) peak',
      value: `${m.peak.toFixed(2)} (${m.peakKind})`,
      pushes:
        m.peak < 0.5
          ? 'Paramagnetic'
          : m.peakKind === 'uniform'
            ? 'Ferromagnetic'
            : m.peakKind === 'checkerboard'
              ? 'Antiferromagnetic'
              : 'Unknown',
    })
  }
  return { probs, top, confidence: probs[top], notes }
}

export function explainMistake(model: ModelId, pred: Phase, truth: Phase): string {
  if (model === 'v1' && pred === 'Paramagnetic') {
    if (truth === 'Ferromagnetic')
      return 'The domains point in opposite directions, so their magnetization cancels. The detector only sees the total, so it concludes "disorder". Zero magnetization does not mean a system is disordered.'
    if (truth === 'Frustrated')
      return 'Frustrated spins have no net or checkerboard order, so both of its features read near zero. It was never trained on triangular lattices and cannot tell frustration from heat.'
    if (truth === 'Unknown')
      return 'Stripes cancel out in both the uniform and the checkerboard average. A pattern the model has never seen gets squeezed into a familiar label.'
  }
  if (model === 'v2' && truth === 'Unknown')
    return 'In a stripe pattern each spin agrees with two neighbours and disagrees with two, so the neighbour correlation is exactly zero, just like random spins. Local statistics alone cannot see the long-range pattern.'
  if (model === 'v2' && pred === 'Frustrated')
    return 'The model learned "negative correlation without order means frustration". That shortcut fails for a square-lattice antiferromagnet near its critical point, where nothing is frustrated at all.'
  if (truth === 'Critical' || pred === 'Critical')
    return 'Near a phase transition, fluctuations happen at every scale and a single snapshot is genuinely ambiguous. Physicists average over many configurations and system sizes.'
  return `The features the model relies on look like a typical ${pred.toLowerCase()} sample, but the full structure of the configuration says ${truth.toLowerCase()}. The model learned a correlation, not the underlying physics.`
}
