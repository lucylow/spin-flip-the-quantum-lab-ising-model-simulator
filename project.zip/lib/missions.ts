import type { ModelId } from './detector'
import type { Metrics, Preset } from './ising'
import type { LabParams } from './lab-engine'

export interface MissionContext {
  metrics: Metrics
  params: LabParams
  fools: number
  model: ModelId
  tcError: number | null
}

export interface MissionStatus {
  done: boolean
  progress: number
  label: string
}

export interface Mission {
  id: string
  chapter: string
  title: string
  brief: string
  objective: string
  hint: string
  tab?: 'battle' | 'hunter'
  setup?: { params: Partial<LabParams>; preset: Preset }
  check: (ctx: MissionContext) => MissionStatus
}

const clamp = (v: number) => Math.max(0, Math.min(1, v))

export const MISSIONS: Mission[] = [
  {
    id: 'magnet',
    chapter: 'Magnetism',
    title: 'Create a Magnet',
    brief: 'A hot sample of iron-like spins is completely disordered.',
    objective: 'Reach a net magnetization |m| of at least 0.90.',
    hint: 'Lower the temperature below about 2.3 and press Run. Painting a seed region can speed things up.',
    setup: { params: { geometry: 'square', J: 1, T: 3.2, h: 0 }, preset: 'random' },
    check: ({ metrics }) => ({
      done: metrics.absM >= 0.9,
      progress: clamp(metrics.absM / 0.9),
      label: `|m| = ${metrics.absM.toFixed(2)} / 0.90`,
    }),
  },
  {
    id: 'checkerboard',
    chapter: 'Magnetism',
    title: 'The Checkerboard',
    brief: 'This material has antiferromagnetic interactions: neighbours want to disagree.',
    objective: 'Reach a staggered magnetization |mₛ| of at least 0.90.',
    hint: 'Keep J < 0 and cool slowly. Notice that |m| stays near zero even when the sample is perfectly ordered.',
    setup: { params: { geometry: 'square', J: -1, T: 3.2, h: 0 }, preset: 'random' },
    check: ({ metrics }) => ({
      done: metrics.absMs >= 0.9,
      progress: clamp(metrics.absMs / 0.9),
      label: `|mₛ| = ${metrics.absMs.toFixed(2)} / 0.90`,
    }),
  },
  {
    id: 'field',
    chapter: 'Magnetism',
    title: 'Polarize a Paramagnet',
    brief: 'The sample is stuck above its Curie temperature. Cooling is not allowed.',
    objective: 'Reach |m| ≥ 0.70 while keeping T ≥ 3.0.',
    hint: 'An external magnetic field h rewards spins that point along it. Try h around 1.5.',
    setup: { params: { geometry: 'square', J: 1, T: 3.5, h: 0 }, preset: 'random' },
    check: ({ metrics, params }) => ({
      done: metrics.absM >= 0.7 && params.T >= 3,
      progress: params.T >= 3 ? clamp(metrics.absM / 0.7) : 0,
      label: params.T < 3 ? 'Temperature too low' : `|m| = ${metrics.absM.toFixed(2)} / 0.70`,
    }),
  },
  {
    id: 'triangle',
    chapter: 'Frustration',
    title: 'The Impossible Triangle',
    brief: 'A triangular lattice where every pair of neighbours wants to point opposite ways.',
    objective: 'Cool to T ≤ 0.6 and push unsatisfied bonds down to the true minimum.',
    hint: 'Switch the view to Bonds to see unhappy links in red. Can you ever get to zero? Try it, then find out why not.',
    setup: { params: { geometry: 'triangular', J: -1, T: 2.5, h: 0 }, preset: 'random' },
    check: ({ metrics, params }) => ({
      done:
        params.geometry === 'triangular' &&
        params.J === -1 &&
        params.T <= 0.6 &&
        metrics.unsatisfied <= 0.345,
      progress: clamp((1 - metrics.unsatisfied) / (2 / 3)),
      label: `${(metrics.unsatisfied * 100).toFixed(1)}% unsatisfied (minimum 33.3%)`,
    }),
  },
  {
    id: 'critical',
    chapter: 'Criticality',
    title: 'Find the Critical Temperature',
    brief: 'Where exactly does the magnet lose its order?',
    objective: 'Run a cooling sweep in Phase Hunter and estimate T꜀ within ±0.30.',
    hint: 'Look for where the order parameter rises steeply and the susceptibility peaks.',
    tab: 'hunter',
    setup: { params: { geometry: 'square', J: 1, h: 0 }, preset: 'random' },
    check: ({ tcError }) => ({
      done: tcError !== null && tcError <= 0.3,
      progress: tcError === null ? 0 : clamp(1 - (tcError - 0.3) / 2),
      label: tcError === null ? 'No estimate submitted' : `Error ${tcError.toFixed(2)}`,
    }),
  },
  {
    id: 'fool',
    chapter: 'Machine Learning',
    title: 'Fool the Detector',
    brief: 'The lab’s AI classifies phases from snapshots. Find a configuration where it is wrong.',
    objective: 'Submit one configuration that the AI misclassifies.',
    hint: 'An ordered state with zero net magnetization is a good place to start.',
    tab: 'battle',
    check: ({ fools }) => ({
      done: fools >= 1,
      progress: clamp(fools),
      label: `${fools} weakness${fools === 1 ? '' : 'es'} found`,
    }),
  },
  {
    id: 'train',
    chapter: 'Machine Learning',
    title: 'Train a Better Detector',
    brief: 'Mistakes are training data. Use them to improve the model.',
    objective: 'Retrain the detector to version 2, then 3.',
    hint: 'Each retrain needs two distinct weaknesses of the current model.',
    tab: 'battle',
    check: ({ model }) => ({
      done: model === 'v3',
      progress: model === 'v1' ? 0 : model === 'v2' ? 0.5 : 1,
      label: `Detector ${model}`,
    }),
  },
]
