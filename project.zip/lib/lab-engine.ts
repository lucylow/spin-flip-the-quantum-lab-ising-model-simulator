import {
  applyPreset,
  createLattice,
  measure,
  metropolis,
  mulberry32,
  quickOrder,
  type Coupling,
  type Geometry,
  type Lattice,
  type Metrics,
  type Preset,
} from './ising'

export interface LabParams {
  geometry: Geometry
  L: number
  J: Coupling
  T: number
  h: number
  speed: number
}

export interface SweepPoint {
  T: number
  order: number
  chi: number
  energy: number
}

export interface LabSnapshot {
  params: LabParams
  running: boolean
  busy: string | null
  metrics: Metrics
  version: number
}

export const DEFAULT_PARAMS: LabParams = {
  geometry: 'square',
  L: 32,
  J: 1,
  T: 3.2,
  h: 0,
  speed: 2,
}

type Job = { label: string; gen: Generator<void, void, void>; maxStepsPerFrame: number }

export class LabEngine {
  lattice: Lattice
  private rng = mulberry32(1337)
  private snapshot: LabSnapshot
  private listeners = new Set<() => void>()
  private drawListeners = new Set<() => void>()
  private raf = 0
  private dirty = true
  private measureDirty = false
  private lastMeasure = 0
  private job: Job | null = null

  constructor(params: LabParams = DEFAULT_PARAMS) {
    this.lattice = createLattice(params.L, params.geometry)
    applyPreset(this.lattice, 'random', this.rng)
    this.snapshot = {
      params,
      running: false,
      busy: null,
      metrics: measure(this.lattice, params.J, params.h),
      version: 0,
    }
  }

  getSnapshot = () => this.snapshot

  subscribe = (fn: () => void) => {
    this.listeners.add(fn)
    return () => {
      this.listeners.delete(fn)
    }
  }

  onDraw(fn: () => void) {
    this.drawListeners.add(fn)
    return () => {
      this.drawListeners.delete(fn)
    }
  }

  private update(patch: Partial<LabSnapshot>) {
    this.snapshot = { ...this.snapshot, ...patch }
    for (const fn of this.listeners) fn()
  }

  private remeasure() {
    const { J, h } = this.snapshot.params
    this.update({
      metrics: measure(this.lattice, J, h),
      version: this.snapshot.version + 1,
    })
    this.measureDirty = false
    this.lastMeasure = performance.now()
  }

  touch() {
    this.dirty = true
    this.measureDirty = true
  }

  start() {
    if (this.raf) return
    const loop = () => {
      this.raf = requestAnimationFrame(loop)
      this.tick()
    }
    this.raf = requestAnimationFrame(loop)
  }

  stop() {
    cancelAnimationFrame(this.raf)
    this.raf = 0
  }

  private tick() {
    const { params, running } = this.snapshot
    if (this.job) {
      const started = performance.now()
      let steps = 0
      while (performance.now() - started < 12 && steps < this.job.maxStepsPerFrame) {
        const r = this.job.gen.next()
        steps++
        if (r.done) {
          this.job = null
          this.update({ busy: null })
          break
        }
      }
      this.touch()
    } else if (running) {
      metropolis(
        this.lattice,
        params.J,
        params.h,
        params.T,
        Math.round(params.speed * this.lattice.N),
        this.rng,
      )
      this.touch()
    }
    if (this.dirty) {
      this.dirty = false
      for (const fn of this.drawListeners) fn()
    }
    if (this.measureDirty && performance.now() - this.lastMeasure > 140) this.remeasure()
  }

  setParams(patch: Partial<LabParams>) {
    const prev = this.snapshot.params
    const next = { ...prev, ...patch }
    if (next.L !== prev.L || next.geometry !== prev.geometry) {
      this.lattice = createLattice(next.L, next.geometry)
      applyPreset(this.lattice, 'random', this.rng)
    }
    this.update({ params: next })
    this.touch()
    this.remeasure()
  }

  setRunning(running: boolean) {
    this.update({ running })
  }

  step(sweeps = 1) {
    const { J, h, T } = this.snapshot.params
    metropolis(this.lattice, J, h, T, sweeps * this.lattice.N, this.rng)
    this.touch()
  }

  preset(p: Preset) {
    applyPreset(this.lattice, p, this.rng)
    this.touch()
    this.remeasure()
  }

  setSpin(i: number, value: 1 | -1) {
    if (this.lattice.spins[i] === value) return
    this.lattice.spins[i] = value
    this.touch()
  }

  copySpins() {
    return {
      spins: this.lattice.spins.slice(),
      L: this.lattice.L,
      geometry: this.lattice.geometry,
    }
  }

  get busy() {
    return this.snapshot.busy
  }

  runFor(sweeps: number, onDone: () => void) {
    const engine = this
    this.update({ busy: 'Running experiment', running: false })
    this.job = {
      label: 'experiment',
      maxStepsPerFrame: 2,
      gen: (function* () {
        for (let s = 0; s < sweeps; s++) {
          engine.step(1)
          yield
        }
        engine.remeasure()
        onDone()
      })(),
    }
  }

  runSweep(
    cfg: { from: number; to: number; steps: number; equil: number; samples: number },
    onPoint: (p: SweepPoint, progress: number) => void,
    onDone: (points: SweepPoint[]) => void,
  ) {
    const engine = this
    this.update({ busy: 'Cooling sweep', running: false })
    this.job = {
      label: 'sweep',
      maxStepsPerFrame: 400,
      gen: (function* () {
        const points: SweepPoint[] = []
        const { J, h, geometry } = engine.snapshot.params
        const useStaggered = geometry === 'square' && J < 0
        for (let k = 0; k < cfg.steps; k++) {
          const T = cfg.from + ((cfg.to - cfg.from) * k) / (cfg.steps - 1)
          engine.update({ params: { ...engine.snapshot.params, T } })
          const flips = engine.lattice.N
          for (let s = 0; s < cfg.equil; s++) {
            metropolis(engine.lattice, J, h, T, flips, engine.rng)
            yield
          }
          let sumO = 0
          let sumO2 = 0
          let sumE = 0
          for (let s = 0; s < cfg.samples; s++) {
            metropolis(engine.lattice, J, h, T, flips, engine.rng)
            const q = quickOrder(engine.lattice, J)
            const o = Math.abs(useStaggered ? q.ms : q.m)
            sumO += o
            sumO2 += o * o
            sumE += q.energy
            yield
          }
          const mean = sumO / cfg.samples
          const chi = (engine.lattice.N * (sumO2 / cfg.samples - mean * mean)) / T
          const point = { T, order: mean, chi, energy: sumE / cfg.samples }
          points.push(point)
          onPoint(point, (k + 1) / cfg.steps)
        }
        engine.remeasure()
        onDone(points)
      })(),
    }
  }

  cancelJob() {
    this.job = null
    this.update({ busy: null })
  }
}
