import type { Phase } from './ising'

export interface Explanation {
  title: string
  what: string
  why: string
  equation: string
  symbols: { symbol: string; meaning: string }[]
  physics: string
  quiz: { question: string; options: string[]; correct: number; feedback: string }
}

const ising = {
  equation: 'H = −J Σ⟨i,j⟩ sᵢ sⱼ − h Σᵢ sᵢ',
  symbols: [
    { symbol: 'H', meaning: 'total energy of the configuration' },
    { symbol: 'J', meaning: 'interaction strength (J > 0 ferro, J < 0 antiferro)' },
    { symbol: 'sᵢ', meaning: 'spin at site i, either +1 (up) or −1 (down)' },
    { symbol: '⟨i,j⟩', meaning: 'sum over neighbouring pairs only' },
    { symbol: 'h', meaning: 'external magnetic field' },
  ],
}

export const EXPLANATIONS: Record<Phase, Explanation> = {
  Ferromagnetic: {
    title: 'You created a ferromagnet',
    what: 'Neighbouring spins line up in the same direction, forming large aligned regions. If one region dominates, the whole sample becomes a magnet.',
    why: 'With J > 0, every aligned pair lowers the energy. At low temperature the system has too little thermal energy to break these bonds, so alignment spreads.',
    ...ising,
    physics:
      'The order parameter is the magnetization m = (1/N) Σ sᵢ. Two opposing domains are still ferromagnetic order: m can be near zero while the structure factor S(q) peaks at q ≈ 0.',
    quiz: {
      question: 'What happens if you raise the temperature far above T꜀ ≈ 2.27?',
      options: [
        'The spins become more disordered',
        'Every spin becomes permanently aligned',
        'The material stops having atoms',
      ],
      correct: 0,
      feedback:
        'Thermal fluctuations flip spins against their neighbours. Above the Curie temperature long-range order melts away.',
    },
  },
  Antiferromagnetic: {
    title: 'You created an antiferromagnet',
    what: 'Neighbouring spins point in alternating directions, making a checkerboard. The net magnetization is almost zero.',
    why: 'With J < 0, opposite neighbours lower the energy. On a square lattice every bond can be satisfied at once by alternating.',
    ...ising,
    physics:
      'Here the useful order parameter is the staggered magnetization mₛ = (1/N) Σ (−1)^(x+y) sᵢ. The system is highly ordered even though m ≈ 0: order and magnetization are different things.',
    quiz: {
      question: 'Is a perfect checkerboard ordered or disordered?',
      options: [
        'Disordered, because the magnetization is zero',
        'Highly ordered, with a hidden staggered pattern',
        'Neither, it is a liquid',
      ],
      correct: 1,
      feedback:
        'Every spin is exactly predictable from its position. That is perfect order, just not ferromagnetic order.',
    },
  },
  Paramagnetic: {
    title: 'The sample is paramagnetic',
    what: 'Spins point in random directions and constantly flip. There is no pattern beyond a few neighbours.',
    why: 'Thermal energy kT is large compared with the coupling J, so random flips that cost energy are accepted often. Entropy wins over energy.',
    ...ising,
    physics:
      'In the Metropolis algorithm a flip costing ΔE is accepted with probability e^(−ΔE/T). At high T this approaches 1, so the configuration is nearly random and correlations decay within a few sites.',
    quiz: {
      question: 'What does an external field h do to a paramagnet?',
      options: [
        'Nothing, paramagnets ignore fields',
        'It destroys the lattice',
        'It tilts the balance so more spins point along the field',
      ],
      correct: 2,
      feedback:
        'The −h Σ sᵢ term rewards spins aligned with the field, producing induced magnetization even above T꜀.',
    },
  },
  Frustrated: {
    title: 'You found geometric frustration',
    what: 'On a triangle, if two spins point opposite to each other, the third cannot oppose both. At least one bond per triangle stays unhappy.',
    why: 'The geometry itself makes it impossible to satisfy every antiferromagnetic interaction at once. Instead of one ground state there are enormously many equally good ones.',
    ...ising,
    physics:
      'The triangular Ising antiferromagnet has an extensive ground-state entropy (Wannier, 1950): S/N ≈ 0.323 k even at T = 0. Frustration like this is a route to exotic states such as quantum spin liquids.',
    quiz: {
      question: 'What is the lowest possible fraction of unsatisfied bonds here?',
      options: ['0%, with enough effort', 'One third', 'All of them'],
      correct: 1,
      feedback:
        'Every triangle has at least one unhappy bond, and each bond is shared, which works out to exactly one third of all bonds.',
    },
  },
  Critical: {
    title: 'You are near a critical point',
    what: 'Clusters of aligned spins of every size appear and dissolve. The picture looks like fractal islands.',
    why: 'Energy and entropy are almost perfectly balanced, so the system cannot decide between order and disorder. Fluctuations become large and long-ranged.',
    ...ising,
    physics:
      'At T꜀ = 2/ln(1+√2) ≈ 2.269 (Onsager, 1944) the correlation length diverges and the susceptibility χ = N(⟨m²⟩ − ⟨|m|⟩²)/T peaks. In a finite sample the transition is rounded into a smooth crossover.',
    quiz: {
      question: 'Why is a snapshot near T꜀ hard to classify?',
      options: [
        'Fluctuations exist on all length scales',
        'The spins stop moving',
        'The lattice changes shape',
      ],
      correct: 0,
      feedback:
        'With no characteristic length scale, a single configuration can look ordered at one zoom and disordered at another.',
    },
  },
  Unknown: {
    title: 'An unconventional pattern',
    what: 'The spins form an ordered pattern, such as stripes, that is neither uniform nor a checkerboard.',
    why: 'This configuration is ordered over long distances, but the standard labels do not fit. With these couplings it may also not be the lowest-energy state.',
    ...ising,
    physics:
      'The structure factor S(q) = |Σ sᵢ e^(−iq·rᵢ)|²/N² reveals hidden order: stripes peak at q = (π, 0). Real materials with competing interactions, like J₁–J₂ models, can stabilize stripes.',
    quiz: {
      question: 'Which tool reveals the stripe order?',
      options: [
        'The total magnetization',
        'The Fourier structure factor S(q)',
        'The number of atoms',
      ],
      correct: 1,
      feedback:
        'Averages cancel for stripes, but a Fourier transform shows a sharp peak at the stripe wavevector.',
    },
  },
}
