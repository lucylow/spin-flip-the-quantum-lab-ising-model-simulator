import type { Phase, Preset } from './ising'
import type { LabParams } from './lab-engine'

export type MaterialFamily = 'Ferromagnet' | 'Antiferromagnet' | 'Frustrated' | 'Model system'

export interface Material {
  id: string
  name: string
  formula: string
  family: MaterialFamily
  realTc: string
  discovered: string
  description: string
  funFact: string
  params: Partial<LabParams>
  preset: Preset
}

export const MATERIALS: Material[] = [
  {
    id: 'iron',
    name: 'Iron',
    formula: 'Fe',
    family: 'Ferromagnet',
    realTc: '1043 K',
    discovered: 'Antiquity',
    description:
      'The classic magnet. Neighbouring spins want to align, so below its Curie point iron forms large uniform domains.',
    funFact: 'Above 1043 K a fridge magnet made of iron would simply fall off.',
    params: { geometry: 'square', J: 1, T: 1.6, h: 0 },
    preset: 'domains',
  },
  {
    id: 'magnetite',
    name: 'Magnetite',
    formula: 'Fe₃O₄',
    family: 'Ferromagnet',
    realTc: '858 K',
    discovered: '~600 BC',
    description:
      'Lodestone. A natural magnet used in the first compasses. Strong external fields easily saturate it.',
    funFact: 'Some bacteria grow chains of magnetite crystals to navigate along Earth’s field.',
    params: { geometry: 'square', J: 1, T: 2.0, h: 0.4 },
    preset: 'random',
  },
  {
    id: 'gadolinium',
    name: 'Gadolinium',
    formula: 'Gd',
    family: 'Ferromagnet',
    realTc: '293 K',
    discovered: '1880',
    description:
      'Its Curie point sits right at room temperature, so it hovers near criticality on a warm day.',
    funFact: 'Used in magnetic refrigeration prototypes because of this near-room-temperature transition.',
    params: { geometry: 'square', J: 1, T: 2.27, h: 0 },
    preset: 'random',
  },
  {
    id: 'mno',
    name: 'Manganese oxide',
    formula: 'MnO',
    family: 'Antiferromagnet',
    realTc: '118 K',
    discovered: '1949 (neutron diffraction)',
    description:
      'The first material whose antiferromagnetic order was directly seen. Neighbours point opposite, giving zero net moment.',
    funFact: 'Clifford Shull’s neutron experiment on MnO contributed to his 1994 Nobel Prize.',
    params: { geometry: 'square', J: -1, T: 1.4, h: 0 },
    preset: 'checkerboard',
  },
  {
    id: 'cr2o3',
    name: 'Chromium oxide',
    formula: 'Cr₂O₃',
    family: 'Antiferromagnet',
    realTc: '307 K',
    discovered: '1959',
    description:
      'A room-temperature antiferromagnet. Hidden order: strong staggered magnetization but no visible pull on a compass.',
    funFact: 'It was the first material shown to be magnetoelectric.',
    params: { geometry: 'square', J: -1, T: 2.0, h: 0 },
    preset: 'random',
  },
  {
    id: 'herbertsmithite',
    name: 'Herbertsmithite',
    formula: 'ZnCu₃(OH)₆Cl₂',
    family: 'Frustrated',
    realTc: 'None observed',
    discovered: '2004',
    description:
      'A quantum spin-liquid candidate. Triangles of antiferromagnetic bonds can never all be satisfied, so order never sets in.',
    funFact: 'Its spins stay disordered down to 50 mK, far below its interaction energy of ~200 K.',
    params: { geometry: 'triangular', J: -1, T: 0.4, h: 0 },
    preset: 'random',
  },
  {
    id: 'spin-ice',
    name: 'Spin ice',
    formula: 'Dy₂Ti₂O₇',
    family: 'Frustrated',
    realTc: 'None (residual entropy)',
    discovered: '1997',
    description:
      'Frustrated geometry leaves a huge number of equally good ground states. The lattice stays restless even when cold.',
    funFact: 'It hosts emergent “magnetic monopole” excitations.',
    params: { geometry: 'triangular', J: -1, T: 0.8, h: 0.2 },
    preset: 'stripes',
  },
  {
    id: 'onsager',
    name: '2D Ising benchmark',
    formula: 'Onsager 1944',
    family: 'Model system',
    realTc: 'T꜀ = 2.269 J/k',
    discovered: '1944',
    description:
      'The exactly-solved square-lattice Ising model, tuned precisely to its critical temperature. Clusters of every size appear.',
    funFact: 'Onsager’s solution was so dense it reportedly took others years to verify.',
    params: { geometry: 'square', J: 1, T: 2.269, h: 0, L: 48 },
    preset: 'random',
  },
]

export interface Researcher {
  id: string
  name: string
  initials: string
  institution: string
  country: string
  score: number
  fools: number
  missions: number
  tcError: number | null
  model: 'v1' | 'v2' | 'v3'
  streak: number
}

export const LEADERBOARD: Researcher[] = [
  { id: 'r1', name: 'Amara Okafor', initials: 'AO', institution: 'ETH Zürich', country: 'CH', score: 2480, fools: 31, missions: 7, tcError: 0.004, model: 'v3', streak: 12 },
  { id: 'r2', name: 'Kenji Watanabe', initials: 'KW', institution: 'RIKEN', country: 'JP', score: 2315, fools: 28, missions: 7, tcError: 0.009, model: 'v3', streak: 9 },
  { id: 'r3', name: 'Lucía Fernández', initials: 'LF', institution: 'ICMM-CSIC', country: 'ES', score: 2190, fools: 26, missions: 7, tcError: 0.011, model: 'v3', streak: 6 },
  { id: 'r4', name: 'Priya Raman', initials: 'PR', institution: 'IISc Bangalore', country: 'IN', score: 1960, fools: 22, missions: 6, tcError: 0.018, model: 'v3', streak: 4 },
  { id: 'r5', name: 'Jonas Becker', initials: 'JB', institution: 'MPI Dresden', country: 'DE', score: 1745, fools: 19, missions: 6, tcError: 0.022, model: 'v2', streak: 3 },
  { id: 'r6', name: 'Chloé Martin', initials: 'CM', institution: 'ENS Paris', country: 'FR', score: 1520, fools: 17, missions: 6, tcError: 0.031, model: 'v2', streak: 5 },
  { id: 'r7', name: 'Samuel Adeyemi', initials: 'SA', institution: 'Univ. of Lagos', country: 'NG', score: 1305, fools: 14, missions: 5, tcError: 0.047, model: 'v2', streak: 2 },
  { id: 'r8', name: 'Mei Lin', initials: 'ML', institution: 'Tsinghua', country: 'CN', score: 1120, fools: 12, missions: 5, tcError: 0.052, model: 'v2', streak: 1 },
  { id: 'r9', name: 'Oliver Grant', initials: 'OG', institution: 'Cambridge', country: 'UK', score: 860, fools: 9, missions: 4, tcError: 0.08, model: 'v2', streak: 0 },
  { id: 'r10', name: 'Sofia Rossi', initials: 'SR', institution: 'SISSA Trieste', country: 'IT', score: 640, fools: 7, missions: 3, tcError: 0.12, model: 'v1', streak: 2 },
  { id: 'r11', name: 'Diego Alvarez', initials: 'DA', institution: 'UNAM', country: 'MX', score: 410, fools: 4, missions: 2, tcError: null, model: 'v1', streak: 1 },
  { id: 'r12', name: 'Hannah Novak', initials: 'HN', institution: 'Charles Univ.', country: 'CZ', score: 180, fools: 2, missions: 1, tcError: null, model: 'v1', streak: 0 },
]

export type ArchiveKind = 'battle' | 'sweep' | 'discovery' | 'retrain'

export interface ArchiveEntry {
  id: string
  kind: ArchiveKind
  researcher: string
  when: string
  title: string
  detail: string
  geometry: 'square' | 'triangular'
  J: 1 | -1
  T: number
  phase: Phase
  outcome: 'success' | 'fail' | 'neutral'
}

export const ARCHIVE: ArchiveEntry[] = [
  { id: 'a1', kind: 'battle', researcher: 'Amara Okafor', when: '12 min ago', title: 'Fooled v3 with a frustrated triangle', detail: 'Detector called it Paramagnetic at 71% confidence. The low-T triangular antiferromagnet has short-range 120° correlations the model ignores.', geometry: 'triangular', J: -1, T: 0.35, phase: 'Frustrated', outcome: 'success' },
  { id: 'a2', kind: 'sweep', researcher: 'Kenji Watanabe', when: '41 min ago', title: 'T꜀ estimate 2.271 on L=48', detail: 'Susceptibility peak at T=2.271 over 24 steps. Error 0.002 versus Onsager.', geometry: 'square', J: 1, T: 2.271, phase: 'Critical', outcome: 'success' },
  { id: 'a3', kind: 'discovery', researcher: 'Lucía Fernández', when: '1 h ago', title: 'Stripe domains survive at T=1.2', detail: 'Hand-painted stripes were metastable for 400 sweeps before coarsening into one domain.', geometry: 'square', J: 1, T: 1.2, phase: 'Ferromagnetic', outcome: 'neutral' },
  { id: 'a4', kind: 'battle', researcher: 'Priya Raman', when: '2 h ago', title: 'v2 saw through two-domain trick', detail: 'Local-correlation features flagged the configuration as Ferromagnetic correctly despite near-zero net |m|.', geometry: 'square', J: 1, T: 1.5, phase: 'Ferromagnetic', outcome: 'fail' },
  { id: 'a5', kind: 'retrain', researcher: 'Jonas Becker', when: '3 h ago', title: 'Retrained detector to v2', detail: 'Two weaknesses of v1 collected: split domains and checkerboard under field.', geometry: 'square', J: -1, T: 1.8, phase: 'Antiferromagnetic', outcome: 'success' },
  { id: 'a6', kind: 'battle', researcher: 'Chloé Martin', when: '5 h ago', title: 'Critical slab fooled v2', detail: 'At T=2.27 the detector split 48/44 between Ferro and Para. Truth: Critical.', geometry: 'square', J: 1, T: 2.27, phase: 'Critical', outcome: 'success' },
  { id: 'a7', kind: 'sweep', researcher: 'Samuel Adeyemi', when: '8 h ago', title: 'Néel temperature on AFM square', detail: 'Staggered order vanished near T=2.25, matching the ferromagnetic T꜀ by symmetry.', geometry: 'square', J: -1, T: 2.25, phase: 'Critical', outcome: 'success' },
  { id: 'a8', kind: 'discovery', researcher: 'Mei Lin', when: 'Yesterday', title: 'No order on triangular AFM down to T=0.1', detail: 'Unhappy-bond fraction plateaued at 33%, the frustration floor of the triangular lattice.', geometry: 'triangular', J: -1, T: 0.1, phase: 'Frustrated', outcome: 'neutral' },
  { id: 'a9', kind: 'battle', researcher: 'Oliver Grant', when: 'Yesterday', title: 'Hot magnet under field', detail: 'Strong h=1.2 at T=4 induced |m|=0.41. v1 called it Ferromagnetic; physics says field-polarized paramagnet.', geometry: 'square', J: 1, T: 4.0, phase: 'Paramagnetic', outcome: 'success' },
  { id: 'a10', kind: 'sweep', researcher: 'Sofia Rossi', when: '2 days ago', title: 'Triangular ferro T꜀ ≈ 3.64', detail: 'Six neighbours per site push the transition up. Estimate within 0.006 of 4/ln3.', geometry: 'triangular', J: 1, T: 3.64, phase: 'Critical', outcome: 'success' },
  { id: 'a11', kind: 'battle', researcher: 'Diego Alvarez', when: '3 days ago', title: 'Checkerboard noise attempt', detail: 'Random noise sprinkled on a Néel state. v1 still read high staggered magnetization correctly.', geometry: 'square', J: -1, T: 1.0, phase: 'Antiferromagnetic', outcome: 'fail' },
  { id: 'a12', kind: 'discovery', researcher: 'Hannah Novak', when: '4 days ago', title: 'Critical slowing down measured', detail: 'Autocorrelation time grew ~8x approaching T꜀ on L=32.', geometry: 'square', J: 1, T: 2.3, phase: 'Critical', outcome: 'neutral' },
]

export interface WeeklyChallenge {
  title: string
  description: string
  reward: number
  endsIn: string
  participants: number
}

export const WEEKLY_CHALLENGE: WeeklyChallenge = {
  title: 'Fool v3 on the triangular lattice',
  description: 'Submit a triangular-lattice configuration that the v3 detector misclassifies with over 60% confidence.',
  reward: 500,
  endsIn: '3d 14h',
  participants: 214,
}
