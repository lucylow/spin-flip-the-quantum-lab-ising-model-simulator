export type Geometry = 'square' | 'triangular'
export type Coupling = 1 | -1

export const PHASES = [
  'Ferromagnetic',
  'Antiferromagnetic',
  'Paramagnetic',
  'Frustrated',
  'Critical',
  'Unknown',
] as const
export type Phase = (typeof PHASES)[number]

export type Preset = 'random' | 'up' | 'down' | 'checkerboard' | 'domains' | 'stripes'

export type Rng = () => number

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export interface Lattice {
  L: number
  N: number
  geometry: Geometry
  z: number
  neighbors: Int32Array
  bonds: Int32Array
  spins: Int8Array
}

export function createLattice(L: number, geometry: Geometry): Lattice {
  const N = L * L
  const z = geometry === 'square' ? 4 : 6
  const idx = (x: number, y: number) => (((y % L) + L) % L) * L + (((x % L) + L) % L)
  const neighbors = new Int32Array(N * z)
  const bonds = new Int32Array(N * z)
  let b = 0
  for (let y = 0; y < L; y++) {
    for (let x = 0; x < L; x++) {
      const i = idx(x, y)
      let nb: number[]
      let down: number[]
      if (geometry === 'square') {
        nb = [idx(x + 1, y), idx(x - 1, y), idx(x, y + 1), idx(x, y - 1)]
        down = [idx(x, y + 1)]
      } else {
        // Brick layout: odd rows are shifted half a cell right, giving six neighbours.
        const a = y % 2 === 0 ? x - 1 : x
        nb = [
          idx(x + 1, y),
          idx(x - 1, y),
          idx(a, y - 1),
          idx(a + 1, y - 1),
          idx(a, y + 1),
          idx(a + 1, y + 1),
        ]
        down = [idx(a, y + 1), idx(a + 1, y + 1)]
      }
      for (let k = 0; k < z; k++) neighbors[i * z + k] = nb[k]
      for (const j of [idx(x + 1, y), ...down]) {
        bonds[b++] = i
        bonds[b++] = j
      }
    }
  }
  return { L, N, geometry, z, neighbors, bonds, spins: new Int8Array(N).fill(1) }
}

export function applyPreset(lat: Lattice, preset: Preset, rng: Rng) {
  const { L, spins } = lat
  for (let y = 0; y < L; y++) {
    for (let x = 0; x < L; x++) {
      const i = y * L + x
      let s = 1
      switch (preset) {
        case 'random':
          s = rng() < 0.5 ? 1 : -1
          break
        case 'up':
          s = 1
          break
        case 'down':
          s = -1
          break
        case 'checkerboard':
          s = (x + y) % 2 === 0 ? 1 : -1
          break
        case 'domains':
          s = y < L / 2 ? 1 : -1
          break
        case 'stripes':
          s = x % 2 === 0 ? 1 : -1
          break
      }
      spins[i] = s
    }
  }
}

export function metropolis(
  lat: Lattice,
  J: number,
  h: number,
  T: number,
  flips: number,
  rng: Rng,
) {
  const { N, z, neighbors, spins } = lat
  const beta = 1 / Math.max(T, 1e-3)
  for (let n = 0; n < flips; n++) {
    const i = (rng() * N) | 0
    let sum = 0
    const base = i * z
    for (let k = 0; k < z; k++) sum += spins[neighbors[base + k]]
    const dE = 2 * spins[i] * (J * sum + h)
    if (dE <= 0 || rng() < Math.exp(-dE * beta)) spins[i] = -spins[i] as 1 | -1
  }
}

export type PeakKind = 'uniform' | 'checkerboard' | 'stripe' | 'other'

export interface Metrics {
  m: number
  absM: number
  ms: number
  absMs: number
  energy: number
  correlation: number
  unsatisfied: number
  wallDensity: number
  entropy: number
  peak: number
  peakKind: PeakKind
  peakK: [number, number]
}

const trigCache = new Map<number, { cos: Float64Array; sin: Float64Array }>()
function trig(L: number) {
  let t = trigCache.get(L)
  if (!t) {
    const cos = new Float64Array(L * L)
    const sin = new Float64Array(L * L)
    for (let k = 0; k < L; k++) {
      for (let n = 0; n < L; n++) {
        const a = (2 * Math.PI * k * n) / L
        cos[k * L + n] = Math.cos(a)
        sin[k * L + n] = Math.sin(a)
      }
    }
    t = { cos, sin }
    trigCache.set(L, t)
  }
  return t
}

function peakKindOf(kx: number, ky: number, L: number): PeakKind {
  const wrap = (k: number) => Math.abs(k > L / 2 ? k - L : k)
  const ax = wrap(kx)
  const ay = wrap(ky)
  const half = L / 2
  const nearZero = (v: number) => v <= 1
  const nearHalf = (v: number) => half - v <= 1
  if (nearZero(ax) && nearZero(ay)) return 'uniform'
  if (nearHalf(ax) && nearHalf(ay)) return 'checkerboard'
  if ((nearHalf(ax) && nearZero(ay)) || (nearZero(ax) && nearHalf(ay))) return 'stripe'
  return 'other'
}

export function quickOrder(lat: Lattice, J: number) {
  const { L, N, spins, bonds } = lat
  let sum = 0
  let stag = 0
  for (let y = 0; y < L; y++) {
    for (let x = 0; x < L; x++) {
      const s = spins[y * L + x]
      sum += s
      stag += (x + y) & 1 ? -s : s
    }
  }
  let bondSum = 0
  for (let b = 0; b < bonds.length; b += 2) bondSum += spins[bonds[b]] * spins[bonds[b + 1]]
  return { m: sum / N, ms: stag / N, energy: (-J * bondSum) / N, sum }
}

export function measure(lat: Lattice, J: number, h: number): Metrics {
  const { L, N, spins, bonds } = lat
  const { m, ms, sum } = quickOrder(lat, J)

  let bondSum = 0
  let unsat = 0
  const nBonds = bonds.length / 2
  for (let b = 0; b < bonds.length; b += 2) {
    const p = spins[bonds[b]] * spins[bonds[b + 1]]
    bondSum += p
    if (J * p < 0) unsat++
  }

  const hist = new Uint32Array(16)
  for (let y = 0; y < L; y++) {
    const y1 = (y + 1) % L
    for (let x = 0; x < L; x++) {
      const x1 = (x + 1) % L
      const code =
        (spins[y * L + x] > 0 ? 1 : 0) |
        (spins[y * L + x1] > 0 ? 2 : 0) |
        (spins[y1 * L + x] > 0 ? 4 : 0) |
        (spins[y1 * L + x1] > 0 ? 8 : 0)
      hist[code]++
    }
  }
  let H = 0
  for (let k = 0; k < 16; k++) {
    if (hist[k] === 0) continue
    const p = hist[k] / N
    H -= p * Math.log2(p)
  }

  const { cos, sin } = trig(L)
  const ar = new Float64Array(L * L)
  const ai = new Float64Array(L * L)
  for (let y = 0; y < L; y++) {
    for (let kx = 0; kx < L; kx++) {
      let r = 0
      let im = 0
      const row = kx * L
      for (let x = 0; x < L; x++) {
        const s = spins[y * L + x]
        r += s * cos[row + x]
        im -= s * sin[row + x]
      }
      ar[y * L + kx] = r
      ai[y * L + kx] = im
    }
  }
  let peak = 0
  let peakK: [number, number] = [0, 0]
  for (let kx = 0; kx < L; kx++) {
    for (let ky = 0; ky < L; ky++) {
      let R = 0
      let I = 0
      const row = ky * L
      for (let y = 0; y < L; y++) {
        const a = ar[y * L + kx]
        const b = ai[y * L + kx]
        const c = cos[row + y]
        const s = sin[row + y]
        R += a * c + b * s
        I += b * c - a * s
      }
      const amp = Math.sqrt(R * R + I * I) / N
      if (amp > peak) {
        peak = amp
        peakK = [kx, ky]
      }
    }
  }

  return {
    m,
    absM: Math.abs(m),
    ms,
    absMs: Math.abs(ms),
    energy: (-J * bondSum - h * sum) / N,
    correlation: bondSum / nBonds,
    unsatisfied: unsat / nBonds,
    wallDensity: (nBonds - bondSum) / 2 / nBonds,
    entropy: H / 4,
    peak,
    peakKind: peakKindOf(peakK[0], peakK[1], L),
    peakK,
  }
}

export interface Truth {
  phase: Phase
  reason: string
}

const pct = (v: number) => `${Math.round(v * 100)}%`

export function classifyTruth(mt: Metrics, geometry: Geometry, J: number): Truth {
  if (geometry === 'triangular' && J < 0 && mt.unsatisfied <= 0.42) {
    return {
      phase: 'Frustrated',
      reason: `${pct(mt.unsatisfied)} of bonds are unsatisfied, close to the unavoidable minimum of 33% on a triangle. No arrangement can do better.`,
    }
  }
  if (mt.peak >= 0.5) {
    switch (mt.peakKind) {
      case 'uniform':
        return {
          phase: 'Ferromagnetic',
          reason:
            mt.absM < 0.5
              ? `Large aligned domains: strong order (structure peak ${mt.peak.toFixed(2)}) even though net magnetization is only ${mt.absM.toFixed(2)}.`
              : `Spins are aligned across the sample (structure peak ${mt.peak.toFixed(2)}).`,
        }
      case 'checkerboard':
        return {
          phase: 'Antiferromagnetic',
          reason: `Neighbours alternate in a checkerboard (staggered order ${mt.absMs.toFixed(2)}), so net magnetization is near zero despite strong order.`,
        }
      case 'stripe':
        return {
          phase: 'Unknown',
          reason: `Stripe order: whole rows or columns alternate. This is long-range order of a kind none of the standard labels describe.`,
        }
      default:
        return {
          phase: 'Unknown',
          reason: `A modulated pattern with wavevector (${mt.peakK[0]}, ${mt.peakK[1]}). Ordered, but not a standard phase.`,
        }
    }
  }
  if (mt.peak >= 0.2 && Math.abs(mt.correlation) >= 0.4) {
    return {
      phase: 'Critical',
      reason: `Large fluctuating clusters: neighbours are correlated (${mt.correlation.toFixed(2)}) but no pattern spans the whole sample yet.`,
    }
  }
  return {
    phase: 'Paramagnetic',
    reason: `Spins are mostly uncorrelated (nearest-neighbour correlation ${mt.correlation.toFixed(2)}). Thermal noise wins.`,
  }
}

export const CRITICAL_T: Record<Geometry, number> = {
  square: 2 / Math.log(1 + Math.SQRT2),
  triangular: 4 / Math.log(3),
}
