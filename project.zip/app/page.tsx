import { QuantumLab } from '@/components/lab/quantum-lab'

export default function Page() {
  return <QuantumLab />
}
