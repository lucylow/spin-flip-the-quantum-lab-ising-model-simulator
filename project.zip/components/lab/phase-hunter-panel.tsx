'use client'

import { Snowflake, Target } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { CRITICAL_T } from '@/lib/ising'
import type { LabEngine, LabParams, SweepPoint } from '@/lib/lab-engine'
import { SPIN_DOWN, SPIN_UP } from './lattice-canvas'
import { Meter } from './segmented'

const T_MIN = 0.5
const W = 560
const H = 240
const PAD = { l: 36, r: 12, t: 12, b: 28 }

function SweepChart({
  points,
  tMax,
  estimate,
  exact,
}: {
  points: SweepPoint[]
  tMax: number
  estimate: number
  exact: number | null
}) {
  const x = (T: number) => PAD.l + ((T - T_MIN) / (tMax - T_MIN)) * (W - PAD.l - PAD.r)
  const y = (v: number) => PAD.t + (1 - v) * (H - PAD.t - PAD.b)
  const sorted = [...points].sort((a, b) => a.T - b.T)
  const chiMax = Math.max(1e-9, ...sorted.map((p) => p.chi))
  const orderPath = sorted.map((p, i) => `${i ? 'L' : 'M'}${x(p.T)},${y(p.order)}`).join(' ')
  const chiPath = sorted.map((p, i) => `${i ? 'L' : 'M'}${x(p.T)},${y(p.chi / chiMax)}`).join(' ')
  const ticks = [1, 2, 3, 4, 5].filter((t) => t <= tMax)

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="h-auto w-full"
      role="img"
      aria-label={`Cooling sweep: order parameter and susceptibility versus temperature, ${points.length} points.`}
    >
      {[0, 0.5, 1].map((v) => (
        <g key={v}>
          <line x1={PAD.l} x2={W - PAD.r} y1={y(v)} y2={y(v)} stroke="currentColor" strokeOpacity={0.08} />
          <text x={PAD.l - 8} y={y(v) + 4} textAnchor="end" className="fill-muted-foreground font-mono text-[10px]">
            {v}
          </text>
        </g>
      ))}
      {ticks.map((t) => (
        <text key={t} x={x(t)} y={H - 8} textAnchor="middle" className="fill-muted-foreground font-mono text-[10px]">
          {t}
        </text>
      ))}
      <text x={W - PAD.r} y={H - 8} textAnchor="end" className="fill-muted-foreground font-mono text-[10px]">
        T
      </text>
      <line
        x1={x(estimate)}
        x2={x(estimate)}
        y1={PAD.t}
        y2={H - PAD.b}
        stroke="currentColor"
        strokeOpacity={0.6}
        strokeDasharray="4 4"
      />
      {exact !== null && (
        <line x1={x(exact)} x2={x(exact)} y1={PAD.t} y2={H - PAD.b} stroke="#ff5a4e" strokeWidth={1.5} />
      )}
      {sorted.length > 1 && (
        <>
          <path d={chiPath} fill="none" stroke={SPIN_DOWN} strokeWidth={2} strokeDasharray="5 3" />
          <path d={orderPath} fill="none" stroke={SPIN_UP} strokeWidth={2.5} />
        </>
      )}
      {sorted.map((p) => (
        <circle key={p.T} cx={x(p.T)} cy={y(p.order)} r={3} fill={SPIN_UP} />
      ))}
    </svg>
  )
}

export function PhaseHunterPanel({
  engine,
  params,
  locked,
  onEstimate,
  onLog,
}: {
  engine: LabEngine
  params: LabParams
  locked: boolean
  onEstimate: (estimate: number, error: number) => void
  onLog: (text: string) => void
}) {
  const tMax = params.geometry === 'triangular' && params.J > 0 ? 5.5 : 4
  const [estimate, setEstimate] = useState(3)
  const [points, setPoints] = useState<SweepPoint[]>([])
  const [progress, setProgress] = useState(0)
  const [sweptFor, setSweptFor] = useState<string | null>(null)
  const [revealed, setRevealed] = useState<number | null>(null)
  const configKey = `${params.geometry}:${params.J}:${params.h}`
  const hasTransition = params.h === 0 && !(params.geometry === 'triangular' && params.J < 0)
  const exact = hasTransition ? CRITICAL_T[params.geometry] : null
  const swept = sweptFor === configKey && points.length > 0

  const chiPeak = points.length ? points.reduce((a, b) => (b.chi > a.chi ? b : a)).T : null

  const run = () => {
    setPoints([])
    setProgress(0)
    setRevealed(null)
    onLog(`Cooling sweep started. Initial prediction: T꜀ ≈ ${estimate.toFixed(2)}`)
    engine.runSweep(
      { from: tMax, to: T_MIN, steps: 16, equil: 150, samples: 150 },
      (p, prog) => {
        setPoints((prev) => [...prev, p])
        setProgress(prog)
      },
      (all) => {
        setSweptFor(configKey)
        const peak = all.reduce((a, b) => (b.chi > a.chi ? b : a))
        onLog(`Cooling sweep finished. Susceptibility peaked near T = ${peak.T.toFixed(2)}`)
      },
    )
  }

  const submit = () => {
    if (exact === null) return
    const err = Math.abs(estimate - exact)
    setRevealed(err)
    onEstimate(estimate, err)
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
      <div className="rounded-lg border border-border bg-background/40 p-4">
        <div className="mb-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="h-0.5 w-4" style={{ background: SPIN_UP }} aria-hidden />
            Order {params.geometry === 'square' && params.J < 0 ? '|mₛ|' : '|m|'}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-0.5 w-4 border-t-2 border-dashed" style={{ borderColor: SPIN_DOWN }} aria-hidden />
            Susceptibility χ (scaled)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3 border-l border-dashed border-foreground/60" aria-hidden />
            Your estimate
          </span>
          {revealed !== null && (
            <span className="flex items-center gap-1.5">
              <span className="h-3 border-l-2 border-destructive" aria-hidden />
              Exact T꜀
            </span>
          )}
        </div>
        <SweepChart points={points} tMax={tMax} estimate={estimate} exact={revealed !== null ? exact : null} />
        {locked && <Meter value={progress} label="Sweep progress" />}
      </div>

      <div className="flex flex-col gap-4 rounded-lg border border-border bg-background/40 p-4">
        <div>
          <p className="font-mono text-[11px] tracking-widest text-primary uppercase">Phase Hunter</p>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            Predict where order appears, then cool the sample from T = {tMax} to {T_MIN} and measure. The current
            lattice, interaction and field are used.
          </p>
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-baseline justify-between">
            <label id="tc-estimate" className="text-xs font-medium">
              Your T꜀ estimate
            </label>
            <span className="font-mono text-sm text-primary tabular-nums">{estimate.toFixed(2)}</span>
          </div>
          <Slider
            aria-labelledby="tc-estimate"
            value={[estimate]}
            min={T_MIN}
            max={tMax}
            step={0.05}
            onValueChange={(v) => setEstimate(Array.isArray(v) ? v[0] : v)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={run} disabled={locked}>
            <Snowflake aria-hidden />
            {swept ? 'Run again' : 'Run cooling sweep'}
          </Button>
          <Button size="sm" variant="outline" onClick={submit} disabled={!swept || exact === null || locked}>
            <Target aria-hidden />
            Submit estimate
          </Button>
        </div>
        {chiPeak !== null && !locked && (
          <p className="text-sm text-muted-foreground">
            Susceptibility peak in your data:{' '}
            <span className="font-mono text-foreground">{chiPeak.toFixed(2)}</span>
          </p>
        )}
        {exact === null && (
          <p className="text-sm leading-relaxed text-accent">
            {params.h !== 0
              ? 'A nonzero field smears out the transition. Set h = 0 to find a sharp T꜀.'
              : 'The triangular antiferromagnet never orders: frustration prevents a transition at any temperature.'}
          </p>
        )}
        {revealed !== null && exact !== null && (
          <p className="text-sm leading-relaxed" aria-live="polite">
            Exact value: <span className="font-mono text-destructive">{exact.toFixed(3)}</span>{' '}
            {params.geometry === 'square' ? '(Onsager, 1944)' : '(Houtappel, 1950)'}. Your error:{' '}
            <span className={revealed <= 0.3 ? 'text-primary' : 'text-accent'}>{revealed.toFixed(2)}</span>.{' '}
            <span className="text-muted-foreground">
              Finite samples round the transition, so the peak shifts slightly with size.
            </span>
          </p>
        )}
      </div>
    </div>
  )
}
