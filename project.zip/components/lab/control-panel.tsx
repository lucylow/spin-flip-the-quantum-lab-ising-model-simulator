'use client'

import { Slider } from '@/components/ui/slider'
import { CRITICAL_T } from '@/lib/ising'
import type { LabEngine, LabParams } from '@/lib/lab-engine'
import { Panel, Segmented } from './segmented'

function SliderRow({
  id,
  label,
  value,
  display,
  min,
  max,
  step,
  disabled,
  onChange,
  hint,
}: {
  id: string
  label: string
  value: number
  display: string
  min: number
  max: number
  step: number
  disabled?: boolean
  onChange: (v: number) => void
  hint?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between">
        <label id={id} className="text-xs font-medium">
          {label}
        </label>
        <span className="font-mono text-xs tabular-nums text-primary">{display}</span>
      </div>
      <Slider
        aria-labelledby={id}
        value={[value]}
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        onValueChange={(v) => onChange(Array.isArray(v) ? v[0] : v)}
      />
      {hint}
    </div>
  )
}

export function ControlPanel({
  engine,
  params,
  locked,
}: {
  engine: LabEngine
  params: LabParams
  locked: boolean
}) {
  const tc = params.J > 0 || params.geometry === 'square' ? CRITICAL_T[params.geometry] : null
  const set = (p: Partial<LabParams>) => engine.setParams(p)

  return (
    <Panel title="Experiment controls">
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <span className="text-xs text-muted-foreground">Lattice</span>
            <Segmented
              label="Lattice geometry"
              value={params.geometry}
              disabled={locked}
              onChange={(geometry) => set({ geometry })}
              options={[
                { value: 'square', label: 'Square' },
                { value: 'triangular', label: 'Triangle' },
              ]}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="text-xs text-muted-foreground">Interaction J</span>
            <Segmented
              label="Interaction sign"
              value={params.J}
              disabled={locked}
              onChange={(J) => set({ J })}
              options={[
                { value: 1, label: 'Ferro' },
                { value: -1, label: 'Anti' },
              ]}
            />
          </div>
        </div>

        <SliderRow
          id="temp-label"
          label="Temperature T"
          value={params.T}
          display={params.T.toFixed(2)}
          min={0.1}
          max={6}
          step={0.05}
          disabled={locked}
          onChange={(T) => set({ T })}
          hint={
            <div className="relative h-3 text-[10px] text-muted-foreground">
              {tc !== null && (
                <span
                  className="absolute -translate-x-1/2 font-mono"
                  style={{ left: `${((tc - 0.1) / 5.9) * 100}%` }}
                >
                  {'▲ T꜀'}
                </span>
              )}
            </div>
          }
        />

        <SliderRow
          id="field-label"
          label="Magnetic field h"
          value={params.h}
          display={params.h.toFixed(2)}
          min={-3}
          max={3}
          step={0.05}
          disabled={locked}
          onChange={(h) => set({ h: Math.abs(h) < 0.03 ? 0 : h })}
        />

        <SliderRow
          id="speed-label"
          label="Simulation speed"
          value={params.speed}
          display={`${params.speed} sweeps/frame`}
          min={0.25}
          max={8}
          step={0.25}
          onChange={(speed) => set({ speed })}
        />

        <div className="flex flex-col gap-1.5">
          <span className="text-xs text-muted-foreground">Sample size</span>
          <Segmented
            label="Sample size"
            value={params.L}
            disabled={locked}
            onChange={(L) => set({ L })}
            options={[16, 24, 32, 48].map((L) => ({ value: L, label: `${L}²` }))}
          />
        </div>
      </div>
    </Panel>
  )
}
