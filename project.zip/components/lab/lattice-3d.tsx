'use client'

import { useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame, type ThreeEvent } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import type { Geometry } from '@/lib/ising'
import type { LabEngine } from '@/lib/lab-engine'
import { SPIN_DOWN, SPIN_UP, type Brush, type ViewMode } from './lattice-canvas'

const INK = '#0b0f17'
const HOT = '#ff5a4e'
const ROW = 0.866

function sitePosition(geometry: Geometry, L: number, i: number): [number, number] {
  const x = i % L
  const y = (i / L) | 0
  if (geometry === 'square') return [x - (L - 1) / 2, y - (L - 1) / 2]
  return [x + (y % 2 ? 0.5 : 0) - L / 2 + 0.25, (y - (L - 1) / 2) * ROW]
}

function useArrowGeometry() {
  return useMemo(() => {
    const shaft = new THREE.CylinderGeometry(0.075, 0.075, 0.5, 10)
    shaft.translate(0, -0.12, 0)
    const head = new THREE.ConeGeometry(0.22, 0.36, 18)
    head.translate(0, 0.3, 0)
    const merged = mergeGeometries([shaft, head])
    shaft.dispose()
    head.dispose()
    return merged
  }, [])
}

interface SceneProps {
  engine: LabEngine
  view: ViewMode
  brush: Brush
  J: number
  T: number
  disabled?: boolean
}

function SpinField({ engine, view, brush, J, T, disabled }: SceneProps) {
  const lat = engine.lattice
  const { N, L, geometry, z } = lat
  const arrows = useRef<THREE.InstancedMesh>(null)
  const pads = useRef<THREE.InstancedMesh>(null)
  const lines = useRef<THREE.LineSegments>(null)
  const arrowGeo = useArrowGeometry()

  const state = useMemo(() => {
    const angle = new Float32Array(N)
    const lift = new Float32Array(N)
    const phase = new Float32Array(N)
    for (let i = 0; i < N; i++) {
      angle[i] = lat.spins[i] > 0 ? 0 : Math.PI
      phase[i] = Math.random() * Math.PI * 2
    }
    const pos = new Float32Array(N * 2)
    for (let i = 0; i < N; i++) {
      const [px, pz] = sitePosition(geometry, L, i)
      pos[i * 2] = px
      pos[i * 2 + 1] = pz
    }
    return { angle, lift, phase, pos }
  }, [N, L, geometry, lat])

  const bondBuffer = useMemo(() => {
    const g = new THREE.BufferGeometry()
    g.setAttribute(
      'position',
      new THREE.BufferAttribute(new Float32Array((lat.bonds.length / 2) * 6), 3),
    )
    g.setDrawRange(0, 0)
    return g
  }, [lat])

  useEffect(() => () => bondBuffer.dispose(), [bondBuffer])

  const tmp = useMemo(
    () => ({
      m: new THREE.Matrix4(),
      q: new THREE.Quaternion(),
      e: new THREE.Euler(),
      p: new THREE.Vector3(),
      s: new THREE.Vector3(1, 1, 1),
      c: new THREE.Color(),
      up: new THREE.Color(SPIN_UP),
      down: new THREE.Color(SPIN_DOWN),
      hot: new THREE.Color(HOT),
      dim: new THREE.Color('#2a3344'),
      pad: new THREE.Color('#161d2a'),
    }),
    [],
  )

  useEffect(() => {
    const mesh = pads.current
    if (!mesh) return
    for (let i = 0; i < N; i++) {
      tmp.m.makeTranslation(state.pos[i * 2], -0.42, state.pos[i * 2 + 1])
      mesh.setMatrixAt(i, tmp.m)
      mesh.setColorAt(i, tmp.pad)
    }
    mesh.instanceMatrix.needsUpdate = true
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
  }, [N, state, tmp])

  useFrame(({ clock }, delta) => {
    const mesh = arrows.current
    const padMesh = pads.current
    if (!mesh || !padMesh) return
    const spins = engine.lattice.spins
    if (spins.length !== N) return
    const t = clock.elapsedTime
    const k = 1 - Math.exp(-delta * 14)
    const wobble = Math.min(0.5, 0.05 + T * 0.07)
    const { angle, lift, phase, pos } = state

    for (let i = 0; i < N; i++) {
      const s = spins[i]
      const target = s > 0 ? 0 : Math.PI
      angle[i] += (target - angle[i]) * k

      let bad = 0
      for (let n = 0; n < z; n++) if (J * s * spins[lat.neighbors[i * z + n]] < 0) bad++
      const u = bad / z
      const targetLift = view === 'energy' ? u * 0.9 : 0
      lift[i] += (targetLift - lift[i]) * k

      const ph = phase[i]
      tmp.e.set(
        angle[i] + Math.sin(t * 2.3 + ph) * wobble,
        0,
        Math.cos(t * 1.9 + ph * 1.3) * wobble,
      )
      tmp.q.setFromEuler(tmp.e)
      tmp.p.set(pos[i * 2], lift[i], pos[i * 2 + 1])
      tmp.m.compose(tmp.p, tmp.q, tmp.s)
      mesh.setMatrixAt(i, tmp.m)

      const mix = angle[i] / Math.PI
      tmp.c.copy(tmp.up).lerp(tmp.down, mix)
      if (view === 'energy') tmp.c.lerp(tmp.hot, u * 0.85)
      else if (view === 'bonds') tmp.c.lerp(tmp.dim, 0.55)
      mesh.setColorAt(i, tmp.c)

      if (view === 'energy') {
        tmp.c.copy(tmp.pad).lerp(tmp.hot, u * 0.7)
      } else {
        tmp.c.copy(tmp.pad).lerp(s > 0 ? tmp.up : tmp.down, 0.22)
      }
      padMesh.setColorAt(i, tmp.c)
    }
    mesh.instanceMatrix.needsUpdate = true
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
    if (padMesh.instanceColor) padMesh.instanceColor.needsUpdate = true

    const line = lines.current
    if (!line) return
    line.visible = view === 'bonds'
    if (view !== 'bonds') return
    const arr = bondBuffer.attributes.position.array as Float32Array
    const b = lat.bonds
    let w = 0
    for (let n = 0; n < b.length; n += 2) {
      const i = b[n]
      const j = b[n + 1]
      if (J * spins[i] * spins[j] >= 0) continue
      const x1 = pos[i * 2]
      const z1 = pos[i * 2 + 1]
      const x2 = pos[j * 2]
      const z2 = pos[j * 2 + 1]
      if (Math.abs(x1 - x2) > 1.5 || Math.abs(z1 - z2) > 1.5) continue
      arr[w++] = x1
      arr[w++] = -0.36
      arr[w++] = z1
      arr[w++] = x2
      arr[w++] = -0.36
      arr[w++] = z2
    }
    bondBuffer.setDrawRange(0, w / 3)
    bondBuffer.attributes.position.needsUpdate = true
  })

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    if (disabled || e.instanceId === undefined || e.delta > 4) return
    e.stopPropagation()
    const i = e.instanceId
    if (brush === 'flip') engine.setSpin(i, engine.lattice.spins[i] > 0 ? -1 : 1)
    else engine.setSpin(i, brush === 'up' ? 1 : -1)
  }

  const padRadius = geometry === 'square' ? 0.44 : 0.48

  return (
    <group>
      <instancedMesh
        ref={arrows}
        args={[arrowGeo, undefined, N]}
        onClick={handleClick}
        frustumCulled={false}
      >
        <meshStandardMaterial roughness={0.35} metalness={0.25} />
      </instancedMesh>
      <instancedMesh
        ref={pads}
        args={[undefined, undefined, N]}
        onClick={handleClick}
        frustumCulled={false}
      >
        <cylinderGeometry args={[padRadius, padRadius, 0.08, geometry === 'square' ? 4 : 6, 1]} />
        <meshStandardMaterial roughness={0.8} metalness={0.1} />
      </instancedMesh>
      <lineSegments ref={lines} geometry={bondBuffer} frustumCulled={false}>
        <lineBasicMaterial color={HOT} transparent opacity={0.95} />
      </lineSegments>
    </group>
  )
}

function NetMoment({ engine, L }: { engine: LabEngine; L: number }) {
  const group = useRef<THREE.Group>(null)
  const smooth = useRef(0)
  const geo = useArrowGeometry()

  useFrame((_, delta) => {
    const g = group.current
    if (!g) return
    const spins = engine.lattice.spins
    let sum = 0
    for (let i = 0; i < spins.length; i++) sum += spins[i]
    const m = sum / spins.length
    smooth.current += (m - smooth.current) * (1 - Math.exp(-delta * 6))
    const mag = Math.max(0.04, Math.abs(smooth.current))
    g.scale.set(1.6, mag * 6, 1.6)
    g.rotation.x = smooth.current >= 0 ? 0 : Math.PI
  })

  return (
    <group position={[L / 2 + 3, 1.2, -L / 2 + 2]}>
      <group ref={group}>
        <mesh geometry={geo}>
          <meshStandardMaterial
            color="#e6edf7"
            emissive="#41cfe4"
            emissiveIntensity={0.35}
            transparent
            opacity={0.9}
          />
        </mesh>
      </group>
    </group>
  )
}

interface Lattice3DProps extends SceneProps {
  L: number
  geometry: Geometry
  label: string
}

export default function Lattice3D(props: Lattice3DProps) {
  const { L, geometry, label } = props
  const dist = L * 0.95 + 6

  return (
    <div
      role="img"
      aria-label={`3D view. ${label}`}
      className="relative aspect-square w-full overflow-hidden rounded-md bg-[#0b0f17] sm:aspect-[4/3]"
    >
      <Canvas
        key={`${geometry}-${L}`}
        dpr={[1, 2]}
        camera={{ position: [dist * 0.55, dist * 0.75, dist * 0.75], fov: 42, near: 0.1, far: 400 }}
        gl={{ antialias: true }}
      >
        <color attach="background" args={[INK]} />
        <fog attach="fog" args={[INK, dist * 0.9, dist * 2.4]} />
        <ambientLight intensity={0.45} />
        <hemisphereLight args={['#bcd6ff', '#1a1410', 0.6]} />
        <directionalLight position={[L * 0.6, L, L * 0.4]} intensity={1.6} />
        <pointLight position={[-L * 0.6, L * 0.4, -L * 0.6]} intensity={L * 4} color={SPIN_DOWN} distance={L * 3} />
        <SpinField {...props} />
        <NetMoment engine={props.engine} L={L} />
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.48, 0]}>
          <planeGeometry args={[L * 4, L * 4]} />
          <meshStandardMaterial color="#0e131d" roughness={1} />
        </mesh>
        <OrbitControls
          enableDamping
          dampingFactor={0.08}
          maxPolarAngle={Math.PI / 2.15}
          minDistance={6}
          maxDistance={dist * 2}
          target={[0, 0, 0]}
        />
      </Canvas>
      <div className="pointer-events-none absolute bottom-2 left-2 flex flex-wrap gap-x-3 gap-y-1 rounded-md bg-background/70 px-2 py-1 font-mono text-[11px] text-muted-foreground backdrop-blur">
        <span>Drag to orbit</span>
        <span>Scroll to zoom</span>
        <span>Click a spin to {props.brush === 'flip' ? 'flip it' : `set it ${props.brush}`}</span>
      </div>
      <div className="pointer-events-none absolute top-2 right-2 rounded-md bg-background/70 px-2 py-1 font-mono text-[11px] text-muted-foreground backdrop-blur">
        Net moment
      </div>
    </div>
  )
}
