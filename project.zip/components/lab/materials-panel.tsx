'use client'

import { FlaskConical, Sparkles } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { MATERIALS, type Material, type MaterialFamily } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

const FAMILIES: ('All' | MaterialFamily)[] = ['All', 'Ferromagnet', 'Antiferromagnet', 'Frustrated', 'Model system']

const FAMILY_TONE: Record<MaterialFamily, string> = {
  Ferromagnet: 'text-primary border-primary/40',
  Antiferromagnet: 'text-accent border-accent/40',
  Frustrated: 'text-destructive border-destructive/40',
  'Model system': 'text-muted-foreground border-border',
}

interface MaterialsPanelProps {
  locked: boolean
  onLoad: (m: Material) => void
}

export function MaterialsPanel({ locked, onLoad }: MaterialsPanelProps) {
  const [family, setFamily] = useState<(typeof FAMILIES)[number]>('All')
  const [selectedId, setSelectedId] = useState(MATERIALS[0].id)
  const list = family === 'All' ? MATERIALS : MATERIALS.filter((m) => m.family === family)
  const selected = MATERIALS.find((m) => m.id === selectedId) ?? MATERIALS[0]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter by family">
        {FAMILIES.map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFamily(f)}
            aria-pressed={family === f}
            className={cn(
              'rounded-full border px-3 py-1 text-xs transition-colors',
              family === f
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border text-muted-foreground hover:text-foreground',
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <ul className="grid gap-2 sm:grid-cols-2">
          {list.map((m) => (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => setSelectedId(m.id)}
                aria-pressed={m.id === selected.id}
                className={cn(
                  'flex h-full w-full flex-col gap-1 rounded-lg border p-3 text-left transition-colors',
                  m.id === selected.id ? 'border-primary bg-muted' : 'border-border hover:bg-muted/50',
                )}
              >
                <span className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-medium">{m.name}</span>
                  <span className="font-mono text-xs text-muted-foreground">{m.formula}</span>
                </span>
                <span className="flex items-center justify-between gap-2">
                  <span className={cn('rounded border px-1.5 py-0.5 text-[10px] uppercase tracking-wide', FAMILY_TONE[m.family])}>
                    {m.family}
                  </span>
                  <span className="font-mono text-[11px] text-muted-foreground">T꜀ {m.realTc}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>

        <article className="flex flex-col gap-3 rounded-lg border border-border bg-background/40 p-4">
          <header className="flex items-start gap-3">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted text-primary">
              <FlaskConical className="size-4" aria-hidden />
            </span>
            <div>
              <h3 className="font-semibold">
                {selected.name} <span className="font-mono text-sm font-normal text-muted-foreground">{selected.formula}</span>
              </h3>
              <p className="text-xs text-muted-foreground">Discovered {selected.discovered}</p>
            </div>
          </header>
          <p className="text-sm leading-relaxed text-muted-foreground">{selected.description}</p>
          <dl className="grid grid-cols-2 gap-2 font-mono text-xs">
            <Stat label="Lattice" value={selected.params.geometry ?? 'square'} />
            <Stat label="Coupling J" value={selected.params.J === -1 ? '−1 (anti)' : '+1 (ferro)'} />
            <Stat label="Sim T" value={(selected.params.T ?? 0).toFixed(2)} />
            <Stat label="Field h" value={(selected.params.h ?? 0).toFixed(2)} />
          </dl>
          <p className="flex gap-2 rounded-md bg-muted/60 p-2.5 text-xs leading-relaxed">
            <Sparkles className="mt-0.5 size-3.5 shrink-0 text-accent" aria-hidden />
            {selected.funFact}
          </p>
          <Button onClick={() => onLoad(selected)} disabled={locked} className="self-start">
            Load into simulator
          </Button>
        </article>
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border px-2.5 py-1.5">
      <dt className="text-[10px] text-muted-foreground uppercase">{label}</dt>
      <dd className="capitalize">{value}</dd>
    </div>
  )
}
