'use client'

import { Flame, Trophy, Users } from 'lucide-react'
import { useMemo, useState } from 'react'
import { LEADERBOARD, WEEKLY_CHALLENGE, type Researcher } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

type SortKey = 'score' | 'fools' | 'tcError'

interface LeaderboardPanelProps {
  player: Omit<Researcher, 'id' | 'initials' | 'institution' | 'country' | 'streak'>
}

export function LeaderboardPanel({ player }: LeaderboardPanelProps) {
  const [sort, setSort] = useState<SortKey>('score')

  const rows = useMemo(() => {
    const me: Researcher & { isMe?: boolean } = {
      ...player,
      id: 'me',
      initials: 'YOU',
      institution: 'Spin Flip Lab',
      country: '—',
      streak: 0,
      isMe: true,
    }
    const all: (Researcher & { isMe?: boolean })[] = [...LEADERBOARD, me]
    return all.sort((a, b) => {
      if (sort === 'tcError') return (a.tcError ?? Infinity) - (b.tcError ?? Infinity)
      return b[sort] - a[sort]
    })
  }, [player, sort])

  const myRank = rows.findIndex((r) => r.isMe) + 1

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">
            You are ranked <span className="font-mono text-foreground">#{myRank}</span> of {rows.length} researchers
          </p>
          <div className="flex gap-1" role="group" aria-label="Sort leaderboard">
            {(
              [
                ['score', 'Score'],
                ['fools', 'AI fooled'],
                ['tcError', 'T꜀ accuracy'],
              ] as const
            ).map(([k, label]) => (
              <button
                key={k}
                type="button"
                aria-pressed={sort === k}
                onClick={() => setSort(k)}
                className={cn(
                  'rounded-md px-2.5 py-1 text-xs transition-colors',
                  sort === k ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-muted/50 text-left text-xs text-muted-foreground">
              <tr>
                <th scope="col" className="px-3 py-2 font-normal">#</th>
                <th scope="col" className="px-3 py-2 font-normal">Researcher</th>
                <th scope="col" className="px-3 py-2 text-right font-normal">Score</th>
                <th scope="col" className="px-3 py-2 text-right font-normal">Fooled</th>
                <th scope="col" className="px-3 py-2 text-right font-normal">ΔT꜀</th>
                <th scope="col" className="px-3 py-2 text-right font-normal">Model</th>
              </tr>
            </thead>
            <tbody className="font-mono text-xs">
              {rows.map((r, i) => (
                <tr
                  key={r.id}
                  className={cn('border-t border-border', r.isMe && 'bg-primary/10')}
                  aria-current={r.isMe ? 'true' : undefined}
                >
                  <td className="px-3 py-2 tabular-nums">
                    {i < 3 ? <Trophy className={cn('size-3.5', MEDAL[i])} aria-label={`Rank ${i + 1}`} /> : i + 1}
                  </td>
                  <td className="px-3 py-2 font-sans">
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          'flex size-7 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold',
                          r.isMe ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground',
                        )}
                        aria-hidden
                      >
                        {r.initials}
                      </span>
                      <span className="flex flex-col">
                        <span className="text-sm">{r.isMe ? 'You' : r.name}</span>
                        <span className="text-[11px] text-muted-foreground">
                          {r.institution}
                          {r.country !== '—' && ` · ${r.country}`}
                        </span>
                      </span>
                      {r.streak >= 5 && (
                        <span className="ml-auto flex items-center gap-0.5 text-[11px] text-accent">
                          <Flame className="size-3" aria-hidden />
                          {r.streak}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">{r.score.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{r.fools}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{r.tcError === null ? '—' : r.tcError.toFixed(3)}</td>
                  <td className="px-3 py-2 text-right">{r.model}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <aside className="flex flex-col gap-3 rounded-lg border border-accent/40 bg-accent/5 p-4">
        <p className="font-mono text-[11px] tracking-widest text-accent uppercase">Weekly challenge</p>
        <h3 className="font-semibold">{WEEKLY_CHALLENGE.title}</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">{WEEKLY_CHALLENGE.description}</p>
        <dl className="grid grid-cols-3 gap-2 font-mono text-xs">
          <div>
            <dt className="text-muted-foreground">Reward</dt>
            <dd className="text-accent">+{WEEKLY_CHALLENGE.reward}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Ends in</dt>
            <dd>{WEEKLY_CHALLENGE.endsIn}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Entrants</dt>
            <dd className="flex items-center gap-1">
              <Users className="size-3" aria-hidden />
              {WEEKLY_CHALLENGE.participants}
            </dd>
          </div>
        </dl>
      </aside>
    </div>
  )
}

const MEDAL = ['text-accent', 'text-foreground', 'text-destructive/80']
