'use client'

import { useState } from 'react'
import { EXPLANATIONS } from '@/lib/explanations'
import type { Truth } from '@/lib/ising'
import { cn } from '@/lib/utils'
import { Segmented } from './segmented'

type Level = 'what' | 'why' | 'physics'

export function ExplainPanel({ truth }: { truth: Truth }) {
  const [level, setLevel] = useState<Level>('what')
  const [answer, setAnswer] = useState<{ phase: string; index: number } | null>(null)
  const ex = EXPLANATIONS[truth.phase]
  const picked = answer?.phase === truth.phase ? answer.index : null

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
      <article className="flex flex-col gap-4 rounded-lg border border-border bg-background/40 p-4">
        <div>
          <p className="font-mono text-[11px] tracking-widest text-primary uppercase">Current state</p>
          <h3 className="mt-1 text-xl font-semibold text-balance">{ex.title}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{truth.reason}</p>
        </div>
        <Segmented
          label="Explanation depth"
          value={level}
          onChange={setLevel}
          options={[
            { value: 'what', label: '1 · What' },
            { value: 'why', label: '2 · Why' },
            { value: 'physics', label: '3 · Physics' },
          ]}
          className="max-w-sm"
        />
        {level === 'what' && <p className="text-pretty leading-relaxed">{ex.what}</p>}
        {level === 'why' && <p className="text-pretty leading-relaxed">{ex.why}</p>}
        {level === 'physics' && (
          <div className="flex flex-col gap-3">
            <p className="rounded-md bg-muted/60 px-3 py-2 text-center font-mono text-sm sm:text-base">
              {ex.equation}
            </p>
            <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
              {ex.symbols.map((s) => (
                <div key={s.symbol} className="contents">
                  <dt className="font-mono text-primary">{s.symbol}</dt>
                  <dd className="text-muted-foreground">{s.meaning}</dd>
                </div>
              ))}
            </dl>
            <p className="text-pretty leading-relaxed">{ex.physics}</p>
          </div>
        )}
      </article>

      <div className="flex flex-col gap-3 rounded-lg border border-border bg-background/40 p-4">
        <p className="font-mono text-[11px] tracking-widest text-accent uppercase">Check yourself</p>
        <p className="font-medium text-pretty">{ex.quiz.question}</p>
        <ul className="flex flex-col gap-2">
          {ex.quiz.options.map((o, i) => {
            const chosen = picked === i
            const correct = i === ex.quiz.correct
            return (
              <li key={o}>
                <button
                  type="button"
                  onClick={() => setAnswer({ phase: truth.phase, index: i })}
                  aria-pressed={chosen}
                  className={cn(
                    'w-full rounded-md border px-3 py-2 text-left text-sm transition-colors',
                    picked === null && 'border-border hover:bg-muted',
                    picked !== null && correct && 'border-primary bg-primary/10',
                    chosen && !correct && 'border-destructive bg-destructive/10',
                    picked !== null && !chosen && !correct && 'border-border opacity-60',
                  )}
                >
                  {o}
                </button>
              </li>
            )
          })}
        </ul>
        {picked !== null && (
          <p className="text-sm leading-relaxed text-muted-foreground" aria-live="polite">
            <span className={picked === ex.quiz.correct ? 'text-primary' : 'text-destructive'}>
              {picked === ex.quiz.correct ? 'Correct. ' : 'Not quite. '}
            </span>
            {ex.quiz.feedback}
          </p>
        )}
      </div>
    </div>
  )
}
