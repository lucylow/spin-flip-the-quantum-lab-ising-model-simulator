'use client'

import { Cpu, FlaskConical } from 'lucide-react'
import type { Prediction } from '@/lib/detector'
import type { Metrics, Truth } from '@/lib/ising'
import { cn } from '@/lib/utils'
import { Meter, Panel } from './segmented'

function Reading({
  label,
  value,
  meter,
  tone,
  title,
}: {
  label: string
  value: string
  meter: number
  tone?: 'primary' | 'accent' | 'destructive' | 'muted'
  title: string
}) {
  return (
    <div className="flex flex-col gap-1.5" title={title}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="font-mono text-sm tabular-nums">{value}</span>
      </div>
      <Meter value={meter} tone={tone} label={label} />
    </div>
  )
}

export function MeasurementsPanel({
  metrics,
  truth,
  prediction,
  modelName,
}: {
  metrics: Metrics
  truth: Truth
  prediction: Prediction
  modelName: string
}) {
  const agrees = prediction.top === truth.phase
  return (
    <Panel title="Measurements">
      <div className="grid grid-cols-2 gap-x-4 gap-y-3">
        <Reading
          label="Magnetization |m|"
          value={metrics.absM.toFixed(2)}
          meter={metrics.absM}
          title="Average spin of the whole sample"
        />
        <Reading
          label="Staggered |mₛ|"
          value={metrics.absMs.toFixed(2)}
          meter={metrics.absMs}
          tone="accent"
          title="Checkerboard order parameter"
        />
        <Reading
          label="Energy / site"
          value={metrics.energy.toFixed(2)}
          meter={(metrics.energy + 3) / 6}
          tone="muted"
          title="Lower is more stable"
        />
        <Reading
          label="Neighbour ⟨sᵢsⱼ⟩"
          value={metrics.correlation.toFixed(2)}
          meter={(metrics.correlation + 1) / 2}
          tone="muted"
          title="+1 all neighbours agree, −1 all disagree"
        />
        <Reading
          label="Unhappy bonds"
          value={`${(metrics.unsatisfied * 100).toFixed(0)}%`}
          meter={metrics.unsatisfied}
          tone="destructive"
          title="Bonds whose energy preference is violated"
        />
        <Reading
          label="Pattern entropy"
          value={metrics.entropy.toFixed(2)}
          meter={metrics.entropy}
          tone="muted"
          title="Shannon entropy of 2×2 spin patterns, an estimate of disorder"
        />
      </div>

      <div className="mt-4 flex flex-col gap-2 border-t border-border pt-3">
        <div className="flex items-start gap-2.5">
          <FlaskConical className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">Physics analyzer</p>
            <p className="text-sm font-medium">{truth.phase}</p>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Cpu
            className={cn('mt-0.5 size-4 shrink-0', agrees ? 'text-primary' : 'text-destructive')}
            aria-hidden
          />
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">AI detector · {modelName}</p>
            <p className="text-sm font-medium">
              {prediction.top}{' '}
              <span className="font-mono text-xs text-muted-foreground">
                {Math.round(prediction.confidence * 100)}%
              </span>
              {!agrees && <span className="ml-2 text-xs text-destructive">disagrees</span>}
            </p>
          </div>
        </div>
      </div>
    </Panel>
  )
}
