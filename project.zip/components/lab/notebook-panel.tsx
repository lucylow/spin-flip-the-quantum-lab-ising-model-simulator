'use client'

import { FlaskConical } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import type { LogEntry } from '@/lib/game'
import type { LabEngine } from '@/lib/lab-engine'
import { cn } from '@/lib/utils'

type Outcome = 'more' | 'same' | 'less'
const OUTCOMES: { value: Outcome; label: string }[] = [
  { value: 'more', label: 'More ordered' },
  { value: 'same', label: 'About the same' },
  { value: 'less', label: 'Less ordered' },
]

const KIND_COLOR: Record<LogEntry['kind'], string> = {
  mission: 'text-primary',
  prediction: 'text-accent',
  ai: 'text-destructive',
  sweep: 'text-primary',
  model: 'text-accent',
}

export function NotebookPanel({
  engine,
  order,
  locked,
  log,
  onLog,
}: {
  engine: LabEngine
  order: number
  locked: boolean
  log: LogEntry[]
  onLog: (text: string) => void
}) {
  const [guess, setGuess] = useState<Outcome | null>(null)
  const [result, setResult] = useState<{ before: number; after: number; actual: Outcome; guess: Outcome } | null>(
    null,
  )

  const run = () => {
    if (!guess) return
    const before = order
    const g = guess
    const T = engine.getSnapshot().params.T
    setResult(null)
    engine.runFor(120, () => {
      const after = engine.getSnapshot().metrics.peak
      const d = after - before
      const actual: Outcome = d > 0.08 ? 'more' : d < -0.08 ? 'less' : 'same'
      setResult({ before, after, actual, guess: g })
      onLog(
        `Prediction at T = ${T.toFixed(2)}: guessed "${OUTCOMES.find((o) => o.value === g)!.label}", order went ${before.toFixed(2)} → ${after.toFixed(2)} (${g === actual ? 'correct' : 'wrong'})`,
      )
    })
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <div className="flex flex-col gap-3 rounded-lg border border-border bg-background/40 p-4">
        <p className="font-mono text-[11px] tracking-widest text-accent uppercase">Predict, then simulate</p>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Set up the lattice and temperature. What will 120 Monte Carlo sweeps do to the order (structure peak,
          currently <span className="font-mono text-foreground">{order.toFixed(2)}</span>)?
        </p>
        <div role="radiogroup" aria-label="Your prediction" className="flex flex-col gap-2">
          {OUTCOMES.map((o) => (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={guess === o.value}
              onClick={() => setGuess(o.value)}
              className={cn(
                'rounded-md border px-3 py-2 text-left text-sm transition-colors',
                guess === o.value ? 'border-accent bg-accent/10' : 'border-border hover:bg-muted',
              )}
            >
              {o.label}
            </button>
          ))}
        </div>
        <Button size="sm" onClick={run} disabled={!guess || locked} className="self-start">
          <FlaskConical aria-hidden />
          Run experiment
        </Button>
        {result && (
          <p className="text-sm leading-relaxed" aria-live="polite">
            <span className={result.guess === result.actual ? 'text-primary' : 'text-destructive'}>
              {result.guess === result.actual ? 'Prediction confirmed. ' : 'Surprise! '}
            </span>
            Order went from <span className="font-mono">{result.before.toFixed(2)}</span> to{' '}
            <span className="font-mono">{result.after.toFixed(2)}</span>.
          </p>
        )}
      </div>

      <div className="rounded-lg border border-border bg-background/40 p-4">
        <p className="mb-3 font-mono text-[11px] tracking-widest text-muted-foreground uppercase">Lab notebook</p>
        {log.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Experiments, mission results and AI battles are recorded here.
          </p>
        ) : (
          <ol className="flex max-h-72 flex-col gap-2 overflow-y-auto pr-1">
            {log.map((e) => (
              <li key={e.id} className="grid grid-cols-[4.5rem_1fr] gap-2 text-sm">
                <span className="font-mono text-[11px] text-muted-foreground tabular-nums">{e.time}</span>
                <span className="leading-relaxed">
                  <span className={cn('mr-1.5 font-mono text-[10px] uppercase', KIND_COLOR[e.kind])}>{e.kind}</span>
                  {e.text}
                </span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  )
}
