'use client'

import { Atom } from 'lucide-react'
import { useEffect, useMemo, useReducer, useState, useSyncExternalStore } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { explainMistake, MODELS, predict } from '@/lib/detector'
import { canRetrain, gameReducer, initialGame, weaknessesFor } from '@/lib/game'
import { classifyTruth } from '@/lib/ising'
import { LabEngine } from '@/lib/lab-engine'
import { MISSIONS, type Mission } from '@/lib/missions'
import { BattlePanel } from './battle-panel'
import { ControlPanel } from './control-panel'
import { ExplainPanel } from './explain-panel'
import type { Brush, ViewMode } from './lattice-canvas'
import { LatticeStage } from './lattice-stage'
import { MeasurementsPanel } from './measurements-panel'
import { MissionsPanel } from './missions-panel'
import { NotebookPanel } from './notebook-panel'
import { PhaseHunterPanel } from './phase-hunter-panel'
import { MaterialsPanel } from './materials-panel'
import { LeaderboardPanel } from './leaderboard-panel'
import { ArchivePanel } from './archive-panel'
import type { ArchiveEntry, Material } from '@/lib/mock-data'

type Tab = 'missions' | 'battle' | 'explain' | 'hunter' | 'notebook' | 'materials' | 'leaderboard' | 'archive'

export function QuantumLab() {
  const [engine] = useState(() => new LabEngine())
  const snap = useSyncExternalStore(engine.subscribe, engine.getSnapshot, engine.getSnapshot)
  const [game, dispatch] = useReducer(gameReducer, initialGame)
  const [tab, setTab] = useState<Tab>('missions')
  const [view, setView] = useState<ViewMode>('spins')
  const [brush, setBrush] = useState<Brush>('flip')

  useEffect(() => {
    engine.start()
    return () => engine.stop()
  }, [engine])

  const { params, metrics, busy } = snap
  const locked = busy !== null
  const truth = useMemo(
    () => classifyTruth(metrics, params.geometry, params.J),
    [metrics, params.geometry, params.J],
  )
  const prediction = useMemo(
    () => predict(game.model, metrics, params.geometry, params.J),
    [game.model, metrics, params.geometry, params.J],
  )

  const fools = game.submissions.filter((s) => s.fooled).length
  const activeMission = MISSIONS.find((m) => m.id === game.activeMission) ?? MISSIONS[0]
  const status = activeMission.check({ metrics, params, fools, model: game.model, tcError: game.tcError })

  useEffect(() => {
    if (status.done && !game.completed.includes(activeMission.id)) {
      dispatch({ type: 'completeMission', id: activeMission.id, title: activeMission.title })
    }
  }, [status.done, activeMission, game.completed])

  const setupMission = (m: Mission) => {
    if (!m.setup) return
    engine.setRunning(false)
    engine.setParams(m.setup.params)
    engine.preset(m.setup.preset)
    dispatch({ type: 'log', kind: 'mission', text: `Loaded sample for "${m.title}"` })
  }

  const submit = () => {
    const fooled = prediction.top !== truth.phase
    const { spins, L, geometry } = engine.copySpins()
    dispatch({
      type: 'submit',
      submission: {
        model: game.model,
        truth: truth.phase,
        truthReason: truth.reason,
        pred: prediction.top,
        confidence: prediction.confidence,
        fooled,
        explanation: fooled ? explainMistake(game.model, prediction.top, truth.phase) : '',
        spins,
        L,
        geometry,
      },
    })
  }

  const loadMaterial = (m: Material) => {
    engine.setParams(m.params)
    engine.preset(m.preset)
    engine.setRunning(true)
    dispatch({ type: 'log', kind: 'mission', text: `Loaded material ${m.name} (${m.formula})` })
  }

  const replayRun = (e: ArchiveEntry) => {
    engine.setParams({ geometry: e.geometry, J: e.J, T: e.T, h: 0 })
    engine.preset('random')
    engine.setRunning(true)
    dispatch({ type: 'log', kind: 'mission', text: `Replaying "${e.title}" by ${e.researcher}` })
  }

  const log = (kind: 'prediction' | 'sweep') => (text: string) => dispatch({ type: 'log', kind, text })

  return (
    <div className="min-h-dvh">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Atom className="size-5" aria-hidden />
            </span>
            <div>
              <h1 className="text-base leading-tight font-semibold">Spin Flip</h1>
              <p className="text-xs text-muted-foreground">The Quantum Lab · Ising model simulator</p>
            </div>
          </div>
          <dl className="flex items-center gap-5 font-mono text-xs">
            <div>
              <dt className="text-muted-foreground">Missions</dt>
              <dd className="tabular-nums">
                {game.completed.length}/{MISSIONS.length}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Detector</dt>
              <dd>{game.model}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Score</dt>
              <dd className="text-primary tabular-nums">{game.score}</dd>
            </div>
          </dl>
        </div>
      </header>

      <main className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 sm:py-6">
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="mx-auto w-full max-w-[680px] lg:mx-0 lg:max-w-none">
            <LatticeStage
              engine={engine}
              snap={snap}
              view={view}
              onView={setView}
              brush={brush}
              onBrush={setBrush}
              truthLabel={`Physics analyzer: ${truth.phase}.`}
            />
          </div>
          <div className="flex flex-col gap-4">
            <ControlPanel engine={engine} params={params} locked={locked} />
            <MeasurementsPanel
              metrics={metrics}
              truth={truth}
              prediction={prediction}
              modelName={`${MODELS[game.model].name} ${game.model}`}
            />
          </div>
        </div>

        <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)} className="rounded-xl border border-border bg-card p-3 sm:p-4">
          <TabsList className="mb-2 w-full justify-start overflow-x-auto sm:w-auto">
            <TabsTrigger value="missions">Missions</TabsTrigger>
            <TabsTrigger value="battle">AI Battle</TabsTrigger>
            <TabsTrigger value="explain">Explain</TabsTrigger>
            <TabsTrigger value="hunter">Phase Hunter</TabsTrigger>
            <TabsTrigger value="notebook">Notebook</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            <TabsTrigger value="archive">Archive</TabsTrigger>
          </TabsList>
          <TabsContent value="materials">
            <MaterialsPanel locked={locked} onLoad={loadMaterial} />
          </TabsContent>
          <TabsContent value="leaderboard">
            <LeaderboardPanel
              player={{
                name: 'You',
                score: game.score,
                fools,
                missions: game.completed.length,
                tcError: game.tcError,
                model: game.model,
              }}
            />
          </TabsContent>
          <TabsContent value="archive">
            <ArchivePanel locked={locked} onReplay={replayRun} />
          </TabsContent>
          <TabsContent value="missions">
            <MissionsPanel
              activeId={activeMission.id}
              completed={game.completed}
              status={status}
              onSelect={(m) => dispatch({ type: 'selectMission', id: m.id })}
              onSetup={setupMission}
              onOpenTab={setTab}
            />
          </TabsContent>
          <TabsContent value="battle">
            <BattlePanel
              model={game.model}
              prediction={prediction}
              truth={truth}
              submissions={game.submissions}
              lastSubmission={game.lastSubmission}
              weaknesses={weaknessesFor(game, game.model)}
              canRetrain={canRetrain(game)}
              locked={locked}
              onSubmit={submit}
              onRetrain={() => dispatch({ type: 'retrain' })}
            />
          </TabsContent>
          <TabsContent value="explain">
            <ExplainPanel truth={truth} />
          </TabsContent>
          <TabsContent value="hunter">
            <PhaseHunterPanel
              engine={engine}
              params={params}
              locked={locked}
              onEstimate={(estimate, error) => dispatch({ type: 'tcEstimate', estimate, error })}
              onLog={log('sweep')}
            />
          </TabsContent>
          <TabsContent value="notebook">
            <NotebookPanel
              engine={engine}
              order={metrics.peak}
              locked={locked}
              log={game.log}
              onLog={log('prediction')}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
