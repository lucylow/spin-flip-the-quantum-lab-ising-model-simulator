'use client'

import { useCallback, useEffect, useRef } from 'react'
import type { Geometry } from '@/lib/ising'
import type { LabEngine } from '@/lib/lab-engine'

export type ViewMode = 'spins' | 'energy' | 'bonds'
export type Brush = 'flip' | 'up' | 'down'

export const SPIN_UP = '#41cfe4'
export const SPIN_DOWN = '#f2a83b'
const INK = '#121722'
const HOT = '#ff5a4e'

export function latticeAspect(geometry: Geometry, L: number) {
  return geometry === 'square' ? 1 : (L + 0.5) / (L * 0.866 + 0.134)
}

interface Layout {
  cs: number
  rowH: number
  pos: (x: number, y: number) => [number, number]
}

function layoutFor(geometry: Geometry, L: number, width: number): Layout {
  if (geometry === 'square') {
    const cs = width / L
    return { cs, rowH: cs, pos: (x, y) => [x * cs + cs / 2, y * cs + cs / 2] }
  }
  const cs = width / (L + 0.5)
  const rowH = cs * 0.866
  return {
    cs,
    rowH,
    pos: (x, y) => [(x + (y % 2 ? 0.5 : 0)) * cs + cs / 2, y * rowH + cs / 2],
  }
}

export function drawSpins(
  ctx: CanvasRenderingContext2D,
  spins: Int8Array,
  L: number,
  geometry: Geometry,
  width: number,
  height: number,
  options: {
    view?: ViewMode
    J?: number
    neighbors?: Int32Array
    bonds?: Int32Array
    z?: number
  } = {},
) {
  const view = options.view ?? 'spins'
  const { cs, pos } = layoutFor(geometry, L, width)
  ctx.fillStyle = INK
  ctx.fillRect(0, 0, width, height)

  const r = geometry === 'square' ? cs * 0.42 : cs * 0.46
  const showArrows = cs >= 13 && view === 'spins'
  const J = options.J ?? 1

  for (let y = 0; y < L; y++) {
    for (let x = 0; x < L; x++) {
      const i = y * L + x
      const s = spins[i]
      const [cx, cy] = pos(x, y)
      let alpha = 1
      if (view === 'energy' && options.neighbors && options.z) {
        let bad = 0
        for (let k = 0; k < options.z; k++) {
          if (J * s * spins[options.neighbors[i * options.z + k]] < 0) bad++
        }
        const u = bad / options.z
        ctx.globalAlpha = 0.18
        ctx.fillStyle = s > 0 ? SPIN_UP : SPIN_DOWN
        ctx.beginPath()
        ctx.arc(cx, cy, r, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = Math.min(1, u * 1.3)
        ctx.fillStyle = HOT
        ctx.beginPath()
        ctx.arc(cx, cy, r * 0.85, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1
        continue
      }
      if (view === 'bonds') alpha = 0.35
      ctx.globalAlpha = alpha
      ctx.fillStyle = s > 0 ? SPIN_UP : SPIN_DOWN
      if (geometry === 'square') {
        ctx.beginPath()
        ctx.roundRect(cx - r, cy - r, r * 2, r * 2, r * 0.35)
        ctx.fill()
      } else {
        ctx.beginPath()
        ctx.arc(cx, cy, r, 0, Math.PI * 2)
        ctx.fill()
      }
      if (showArrows) {
        ctx.strokeStyle = INK
        ctx.fillStyle = INK
        ctx.lineWidth = Math.max(1.5, cs * 0.09)
        const len = r * 0.55
        const dir = s > 0 ? -1 : 1
        ctx.beginPath()
        ctx.moveTo(cx, cy - dir * len)
        ctx.lineTo(cx, cy + dir * len * 0.3)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(cx, cy + dir * len)
        ctx.lineTo(cx - len * 0.55, cy + dir * len * 0.2)
        ctx.lineTo(cx + len * 0.55, cy + dir * len * 0.2)
        ctx.closePath()
        ctx.fill()
      }
    }
  }
  ctx.globalAlpha = 1

  if (view === 'bonds' && options.bonds) {
    ctx.strokeStyle = HOT
    ctx.lineWidth = Math.max(1.5, cs * 0.14)
    ctx.lineCap = 'round'
    ctx.beginPath()
    const b = options.bonds
    for (let k = 0; k < b.length; k += 2) {
      const i = b[k]
      const j = b[k + 1]
      if (J * spins[i] * spins[j] >= 0) continue
      const [x1, y1] = pos(i % L, (i / L) | 0)
      const [x2, y2] = pos(j % L, (j / L) | 0)
      if (Math.abs(x1 - x2) > cs * 1.5 || Math.abs(y1 - y2) > cs * 1.5) continue
      ctx.moveTo(x1, y1)
      ctx.lineTo(x2, y2)
    }
    ctx.stroke()
  }
}

interface LatticeCanvasProps {
  engine: LabEngine
  view: ViewMode
  brush: Brush
  J: number
  geometry: Geometry
  L: number
  disabled?: boolean
  label: string
}

export function LatticeCanvas({
  engine,
  view,
  brush,
  J,
  geometry,
  L,
  disabled,
  label,
}: LatticeCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const wrapRef = useRef<HTMLDivElement>(null)
  const sizeRef = useRef({ w: 0, h: 0 })
  const stroke = useRef<{ visited: Set<number>; value: 1 | -1 | null } | null>(null)

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const { w, h } = sizeRef.current
    if (!w) return
    const dpr = window.devicePixelRatio || 1
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    const lat = engine.lattice
    drawSpins(ctx, lat.spins, lat.L, lat.geometry, w, h, {
      view,
      J,
      neighbors: lat.neighbors,
      bonds: lat.bonds,
      z: lat.z,
    })
  }, [engine, view, J])

  useEffect(() => {
    const wrap = wrapRef.current
    const canvas = canvasRef.current
    if (!wrap || !canvas) return
    const ro = new ResizeObserver(() => {
      const w = wrap.clientWidth
      const h = w / latticeAspect(geometry, L)
      const dpr = window.devicePixelRatio || 1
      canvas.width = Math.round(w * dpr)
      canvas.height = Math.round(h * dpr)
      canvas.style.height = `${h}px`
      sizeRef.current = { w, h }
      draw()
    })
    ro.observe(wrap)
    return () => ro.disconnect()
  }, [geometry, L, draw])

  useEffect(() => {
    draw()
    return engine.onDraw(draw)
  }, [engine, draw])

  const siteAt = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current
    if (!canvas) return -1
    const rect = canvas.getBoundingClientRect()
    const px = clientX - rect.left
    const py = clientY - rect.top
    const { cs, rowH } = layoutFor(geometry, L, rect.width)
    let y: number
    let x: number
    if (geometry === 'square') {
      x = Math.floor(px / cs)
      y = Math.floor(py / cs)
    } else {
      y = Math.floor(py / rowH)
      x = Math.floor(px / cs - (y % 2 ? 0.5 : 0))
    }
    if (x < 0 || y < 0 || x >= L || y >= L) return -1
    return y * L + x
  }

  const paint = (clientX: number, clientY: number) => {
    const s = stroke.current
    if (!s) return
    const i = siteAt(clientX, clientY)
    if (i < 0 || s.visited.has(i)) return
    s.visited.add(i)
    if (brush === 'flip') {
      engine.setSpin(i, engine.lattice.spins[i] > 0 ? -1 : 1)
    } else {
      engine.setSpin(i, brush === 'up' ? 1 : -1)
    }
  }

  return (
    <div ref={wrapRef} className="w-full">
      <canvas
        ref={canvasRef}
        role="img"
        aria-label={label}
        className={`block w-full touch-none rounded-md ${disabled ? 'cursor-wait' : 'cursor-crosshair'}`}
        onPointerDown={(e) => {
          if (disabled) return
          e.currentTarget.setPointerCapture(e.pointerId)
          stroke.current = { visited: new Set(), value: null }
          paint(e.clientX, e.clientY)
        }}
        onPointerMove={(e) => paint(e.clientX, e.clientY)}
        onPointerUp={() => {
          stroke.current = null
        }}
        onPointerCancel={() => {
          stroke.current = null
        }}
      />
    </div>
  )
}

export function SpinThumbnail({
  spins,
  L,
  geometry,
  size = 72,
  label,
}: {
  spins: Int8Array
  L: number
  geometry: Geometry
  size?: number
  label: string
}) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = ref.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return
    const dpr = window.devicePixelRatio || 1
    const h = size / latticeAspect(geometry, L)
    canvas.width = size * dpr
    canvas.height = h * dpr
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    drawSpins(ctx, spins, L, geometry, size, h)
  }, [spins, L, geometry, size])
  return (
    <canvas
      ref={ref}
      role="img"
      aria-label={label}
      style={{ width: size, height: size / latticeAspect(geometry, L) }}
      className="rounded"
    />
  )
}
