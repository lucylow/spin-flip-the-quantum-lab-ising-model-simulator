'use client'

import { Check, Lightbulb, RotateCcw } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { MISSIONS, type Mission, type MissionStatus } from '@/lib/missions'
import { cn } from '@/lib/utils'
import { Meter } from './segmented'

interface MissionsPanelProps {
  activeId: string
  completed: string[]
  status: MissionStatus
  onSelect: (m: Mission) => void
  onSetup: (m: Mission) => void
  onOpenTab: (tab: 'battle' | 'hunter') => void
}

export function MissionsPanel({
  activeId,
  completed,
  status,
  onSelect,
  onSetup,
  onOpenTab,
}: MissionsPanelProps) {
  const [showHint, setShowHint] = useState(false)
  const active = MISSIONS.find((m) => m.id === activeId) ?? MISSIONS[0]
  const isDone = completed.includes(active.id)

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)]">
      <ol className="flex flex-col gap-1" aria-label="Research missions">
        {MISSIONS.map((m, i) => {
          const done = completed.includes(m.id)
          const current = m.id === active.id
          return (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => {
                  setShowHint(false)
                  onSelect(m)
                }}
                aria-current={current ? 'step' : undefined}
                className={cn(
                  'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-colors',
                  current ? 'bg-muted' : 'hover:bg-muted/50',
                )}
              >
                <span
                  className={cn(
                    'flex size-6 shrink-0 items-center justify-center rounded-full border font-mono text-[11px]',
                    done
                      ? 'border-primary bg-primary text-primary-foreground'
                      : current
                        ? 'border-primary text-primary'
                        : 'border-border text-muted-foreground',
                  )}
                >
                  {done ? <Check className="size-3.5" aria-label="Completed" /> : i + 1}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{m.title}</span>
                  <span className="block font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
                    {m.chapter}
                  </span>
                </span>
              </button>
            </li>
          )
        })}
      </ol>

      <article className="flex flex-col gap-4 rounded-lg border border-border bg-background/40 p-4">
        <div>
          <p className="font-mono text-[11px] tracking-widest text-primary uppercase">
            Mission · {active.chapter}
          </p>
          <h3 className="mt-1 text-xl font-semibold text-balance">{active.title}</h3>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{active.brief}</p>
        </div>

        <div className="rounded-md bg-muted/60 p-3">
          <p className="text-xs text-muted-foreground">Objective</p>
          <p className="mt-0.5 text-sm font-medium">{active.objective}</p>
          <div className="mt-3 flex flex-col gap-1.5">
            <Meter value={isDone ? 1 : status.progress} label="Mission progress" />
            <p className="font-mono text-xs text-muted-foreground" aria-live="polite">
              {isDone ? 'Complete' : status.label}
            </p>
          </div>
        </div>

        {isDone && (
          <p className="rounded-md border border-primary/40 bg-primary/10 p-3 text-sm text-primary" role="status">
            Mission complete. Open the Explain tab to see why this happened.
          </p>
        )}

        <div className="flex flex-wrap gap-2">
          {active.setup && (
            <Button size="sm" onClick={() => onSetup(active)}>
              <RotateCcw aria-hidden />
              Load sample
            </Button>
          )}
          {active.tab && (
            <Button size="sm" variant="outline" onClick={() => onOpenTab(active.tab!)}>
              Open {active.tab === 'battle' ? 'AI Battle' : 'Phase Hunter'}
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            aria-expanded={showHint}
            onClick={() => setShowHint((s) => !s)}
          >
            <Lightbulb aria-hidden />
            {showHint ? 'Hide hint' : 'Hint'}
          </Button>
        </div>
        {showHint && <p className="text-sm leading-relaxed text-muted-foreground">{active.hint}</p>}
      </article>
    </div>
  )
}
