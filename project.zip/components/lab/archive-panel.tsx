'use client'

import { Activity, BrainCircuit, Search, Swords, Telescope } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ARCHIVE, type ArchiveEntry, type ArchiveKind } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

const KINDS: { value: 'all' | ArchiveKind; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'battle', label: 'Battles' },
  { value: 'sweep', label: 'Sweeps' },
  { value: 'discovery', label: 'Discoveries' },
  { value: 'retrain', label: 'Retrains' },
]

const ICON = { battle: Swords, sweep: Activity, discovery: Telescope, retrain: BrainCircuit }

const OUTCOME: Record<ArchiveEntry['outcome'], { label: string; tone: string }> = {
  success: { label: 'Success', tone: 'text-primary' },
  fail: { label: 'Failed', tone: 'text-destructive' },
  neutral: { label: 'Observation', tone: 'text-muted-foreground' },
}

interface ArchivePanelProps {
  locked: boolean
  onReplay: (e: ArchiveEntry) => void
}

export function ArchivePanel({ locked, onReplay }: ArchivePanelProps) {
  const [kind, setKind] = useState<'all' | ArchiveKind>('all')
  const [query, setQuery] = useState('')
  const q = query.trim().toLowerCase()
  const entries = ARCHIVE.filter(
    (e) =>
      (kind === 'all' || e.kind === kind) &&
      (!q || `${e.title} ${e.researcher} ${e.detail} ${e.phase}`.toLowerCase().includes(q)),
  )

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1" role="group" aria-label="Filter archive">
          {KINDS.map((k) => (
            <button
              key={k.value}
              type="button"
              aria-pressed={kind === k.value}
              onClick={() => setKind(k.value)}
              className={cn(
                'rounded-md px-2.5 py-1 text-xs transition-colors',
                kind === k.value ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {k.label}
            </button>
          ))}
        </div>
        <label className="relative ml-auto w-full sm:w-64">
          <span className="sr-only">Search archive</span>
          <Search className="pointer-events-none absolute top-1/2 left-2.5 size-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search runs, people, phases"
            className="h-8 w-full rounded-md border border-border bg-background pr-2 pl-8 text-sm placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          />
        </label>
      </div>

      {entries.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
          No archived runs match that filter.
        </p>
      ) : (
        <ul className="grid gap-2 md:grid-cols-2">
          {entries.map((e) => {
            const Icon = ICON[e.kind]
            const outcome = OUTCOME[e.outcome]
            return (
              <li key={e.id} className="flex flex-col gap-2 rounded-lg border border-border p-3">
                <div className="flex items-start gap-3">
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
                    <Icon className="size-4 text-muted-foreground" aria-hidden />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-pretty">{e.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {e.researcher} · {e.when}
                    </p>
                  </div>
                  <span className={cn('font-mono text-[11px]', outcome.tone)}>{outcome.label}</span>
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">{e.detail}</p>
                <div className="mt-auto flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] text-muted-foreground">
                    {e.geometry} · J={e.J > 0 ? '+1' : '−1'} · T={e.T.toFixed(2)} · {e.phase}
                  </span>
                  <Button size="sm" variant="outline" disabled={locked} onClick={() => onReplay(e)}>
                    Replay
                  </Button>
                </div>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
