'use client'

import { BrainCircuit, Crosshair, Lightbulb, Sparkles } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { MODELS, MODEL_ORDER, type ModelId, type Prediction } from '@/lib/detector'
import type { Submission } from '@/lib/game'
import { PHASES, type Truth } from '@/lib/ising'
import { cn } from '@/lib/utils'
import { SpinThumbnail } from './lattice-canvas'

interface BattlePanelProps {
  model: ModelId
  prediction: Prediction
  truth: Truth
  submissions: Submission[]
  lastSubmission: Submission | null
  weaknesses: number
  canRetrain: boolean
  locked: boolean
  onSubmit: () => void
  onRetrain: () => void
}

export function BattlePanel({
  model,
  prediction,
  truth,
  submissions,
  lastSubmission,
  weaknesses,
  canRetrain,
  locked,
  onSubmit,
  onRetrain,
}: BattlePanelProps) {
  const info = MODELS[model]
  const [showHint, setShowHint] = useState(false)
  const fools = submissions.filter((s) => s.fooled)

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
      <div className="flex flex-col gap-4">
        <div className="rounded-lg border border-border bg-background/40 p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <span className="flex size-9 items-center justify-center rounded-md bg-primary/15 text-primary">
                <BrainCircuit className="size-5" aria-hidden />
              </span>
              <div>
                <p className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
                  Opponent · {model}
                </p>
                <h3 className="text-lg font-semibold">{info.name}</h3>
              </div>
            </div>
            <ol className="flex gap-1" aria-label="Model versions">
              {MODEL_ORDER.map((id) => (
                <li
                  key={id}
                  className={cn(
                    'rounded px-1.5 py-0.5 font-mono text-[10px]',
                    id === model
                      ? 'bg-primary text-primary-foreground'
                      : MODEL_ORDER.indexOf(id) < MODEL_ORDER.indexOf(model)
                        ? 'bg-muted text-muted-foreground line-through'
                        : 'bg-muted text-muted-foreground',
                  )}
                >
                  {id}
                </li>
              ))}
            </ol>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{info.description}</p>
          <div className="mt-3 flex flex-wrap gap-1.5" aria-label="Features the model sees">
            {info.features.map((f) => (
              <span key={f} className="rounded-md border border-border px-2 py-0.5 font-mono text-[11px]">
                {f}
              </span>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-background/40 p-4">
          <p className="mb-3 text-xs text-muted-foreground">Live prediction on the current lattice</p>
          <ul className="flex flex-col gap-2">
            {PHASES.map((p) => {
              const prob = prediction.probs[p]
              const isTop = p === prediction.top
              const isTruth = p === truth.phase
              return (
                <li key={p} className="grid grid-cols-[8.5rem_1fr_2.5rem] items-center gap-2 text-xs">
                  <span className={cn('flex items-center gap-1.5', isTop ? 'font-medium' : 'text-muted-foreground')}>
                    {p}
                    {isTruth && (
                      <span className="rounded bg-primary/15 px-1 font-mono text-[9px] text-primary uppercase">
                        physics
                      </span>
                    )}
                  </span>
                  <span className="h-2 overflow-hidden rounded-full bg-muted">
                    <span
                      className={cn(
                        'block h-full rounded-full transition-[width] duration-200',
                        isTop ? (isTruth ? 'bg-primary' : 'bg-destructive') : 'bg-muted-foreground/50',
                      )}
                      style={{ width: `${prob * 100}%` }}
                    />
                  </span>
                  <span className="text-right font-mono tabular-nums">{Math.round(prob * 100)}%</span>
                </li>
              )
            })}
          </ul>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button onClick={onSubmit} disabled={locked}>
              <Crosshair aria-hidden />
              Submit configuration
            </Button>
            <Button
              variant="ghost"
              size="sm"
              aria-expanded={showHint}
              onClick={() => setShowHint((s) => !s)}
            >
              <Lightbulb aria-hidden />
              Weakness hint
            </Button>
          </div>
          {showHint && (
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{info.blindSpot}</p>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {lastSubmission ? (
          <article
            aria-live="polite"
            className={cn(
              'rounded-lg border p-4',
              lastSubmission.fooled ? 'border-destructive/50 bg-destructive/10' : 'border-primary/40 bg-primary/5',
            )}
          >
            <p
              className={cn(
                'font-mono text-[11px] tracking-widest uppercase',
                lastSubmission.fooled ? 'text-destructive' : 'text-primary',
              )}
            >
              {lastSubmission.fooled
                ? lastSubmission.novel
                  ? 'Detector fooled · +100'
                  : 'Detector fooled · known weakness'
                : 'Detector was right'}
            </p>
            <div className="mt-3 flex gap-3">
              <SpinThumbnail
                spins={lastSubmission.spins}
                L={lastSubmission.L}
                geometry={lastSubmission.geometry}
                size={84}
                label="Submitted configuration"
              />
              <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
                <dt className="text-muted-foreground">AI said</dt>
                <dd className="font-medium">
                  {lastSubmission.pred}{' '}
                  <span className="font-mono text-xs text-muted-foreground">
                    {Math.round(lastSubmission.confidence * 100)}%
                  </span>
                </dd>
                <dt className="text-muted-foreground">Physics</dt>
                <dd className="font-medium">{lastSubmission.truth}</dd>
              </dl>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{lastSubmission.truthReason}</p>
            {lastSubmission.fooled && (
              <div className="mt-3 border-t border-border pt-3">
                <p className="text-xs font-medium">Why the AI failed</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {lastSubmission.explanation}
                </p>
              </div>
            )}
          </article>
        ) : (
          <div className="rounded-lg border border-dashed border-border p-4 text-sm leading-relaxed text-muted-foreground">
            Shape the lattice on the left, by painting, loading a pattern, or changing the physics, then submit
            it. A weakness counts when the AI&apos;s label disagrees with the physics analyzer.
          </div>
        )}

        <div className="rounded-lg border border-border bg-background/40 p-4">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-medium">Retraining dataset</p>
            <span className="font-mono text-xs text-muted-foreground">
              {Math.min(weaknesses, 2)}/2 weaknesses of {model}
            </span>
          </div>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            {model === 'v3'
              ? 'Final model reached. It needed physics-informed features to match the analyzer.'
              : 'Find two distinct failure modes of this model to collect enough training data for the next version.'}
          </p>
          <Button className="mt-3" variant="secondary" size="sm" disabled={!canRetrain} onClick={onRetrain}>
            <Sparkles aria-hidden />
            Retrain detector
          </Button>
          {model !== 'v1' && (
            <p className="mt-3 text-xs leading-relaxed text-primary">{MODELS[model].upgradeNote}</p>
          )}
        </div>

        {fools.length > 0 && (
          <div>
            <p className="mb-2 text-xs text-muted-foreground">Adversarial examples</p>
            <ul className="flex flex-wrap gap-2">
              {fools.slice(0, 10).map((s) => (
                <li key={s.id} className="flex flex-col items-center gap-1">
                  <SpinThumbnail
                    spins={s.spins}
                    L={s.L}
                    geometry={s.geometry}
                    size={52}
                    label={`${s.model} said ${s.pred}, physics said ${s.truth}`}
                  />
                  <span className="font-mono text-[9px] text-muted-foreground">
                    {s.model} · {s.truth.slice(0, 5)}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}
