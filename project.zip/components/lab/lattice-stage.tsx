'use client'

import { useState } from 'react'
import dynamic from 'next/dynamic'
import { ArrowDown, ArrowUp, Box, Pause, Play, Repeat2, Square, StepForward } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Preset } from '@/lib/ising'
import type { LabEngine, LabSnapshot } from '@/lib/lab-engine'
import { LatticeCanvas, SPIN_DOWN, SPIN_UP, type Brush, type ViewMode } from './lattice-canvas'
import { Segmented } from './segmented'

const Lattice3D = dynamic(() => import('./lattice-3d'), {
  ssr: false,
  loading: () => (
    <div className="flex aspect-square w-full items-center justify-center rounded-md bg-[#0b0f17] font-mono text-xs text-muted-foreground sm:aspect-[4/3]">
      Loading 3D lattice
    </div>
  ),
})

type Dimension = '2d' | '3d'

const PRESETS: { value: Preset; label: string }[] = [
  { value: 'random', label: 'Random' },
  { value: 'up', label: 'All up' },
  { value: 'checkerboard', label: 'Checkerboard' },
  { value: 'domains', label: 'Two domains' },
  { value: 'stripes', label: 'Stripes' },
]

interface LatticeStageProps {
  engine: LabEngine
  snap: LabSnapshot
  view: ViewMode
  onView: (v: ViewMode) => void
  brush: Brush
  onBrush: (b: Brush) => void
  truthLabel: string
}

export function LatticeStage({
  engine,
  snap,
  view,
  onView,
  brush,
  onBrush,
  truthLabel,
}: LatticeStageProps) {
  const { params, running, busy } = snap
  const locked = busy !== null
  const [dim, setDim] = useState<Dimension>('2d')
  const label = `${params.geometry} lattice of ${params.L} by ${params.L} spins. ${truthLabel}`

  return (
    <section className="flex flex-col gap-3 rounded-xl border border-border bg-card p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => engine.setRunning(!running)}
            disabled={locked}
            aria-label={running ? 'Pause simulation' : 'Run simulation'}
          >
            {running ? <Pause aria-hidden /> : <Play aria-hidden />}
            {running ? 'Pause' : 'Run'}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => engine.step(1)}
            disabled={locked || running}
          >
            <StepForward aria-hidden />
            Sweep
          </Button>
          {busy && (
            <span className="flex items-center gap-1.5 font-mono text-xs text-accent" role="status">
              <span className="size-1.5 animate-pulse rounded-full bg-accent" aria-hidden />
              {busy}
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Segmented
            label="Dimension"
            value={dim}
            onChange={setDim}
            options={[
              { value: '2d', label: '2D', icon: <Square className="size-3.5" aria-hidden /> },
              { value: '3d', label: '3D', icon: <Box className="size-3.5" aria-hidden /> },
            ]}
          />
          <Segmented
            label="View mode"
            value={view}
            onChange={onView}
            options={[
              { value: 'spins', label: 'Spins' },
              { value: 'energy', label: 'Energy' },
              { value: 'bonds', label: 'Bonds' },
            ]}
          />
        </div>
      </div>

      {dim === '3d' ? (
        <Lattice3D
          engine={engine}
          view={view}
          brush={brush}
          J={params.J}
          T={params.T}
          geometry={params.geometry}
          L={params.L}
          disabled={locked}
          label={label}
        />
      ) : (
        <LatticeCanvas
          engine={engine}
          view={view}
          brush={brush}
          J={params.J}
          geometry={params.geometry}
          L={params.L}
          disabled={locked}
          label={label}
        />
      )}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Brush</span>
          <Segmented
            label="Brush"
            value={brush}
            onChange={onBrush}
            options={[
              { value: 'flip', label: 'Flip', icon: <Repeat2 className="size-3.5" aria-hidden /> },
              {
                value: 'up',
                label: 'Up',
                icon: <ArrowUp className="size-3.5" style={{ color: SPIN_UP }} aria-hidden />,
              },
              {
                value: 'down',
                label: 'Down',
                icon: <ArrowDown className="size-3.5" style={{ color: SPIN_DOWN }} aria-hidden />,
              },
            ]}
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Load configuration">
          {PRESETS.map((p) => (
            <Button
              key={p.value}
              size="xs"
              variant="ghost"
              disabled={locked}
              onClick={() => engine.preset(p.value)}
              className="text-muted-foreground hover:text-foreground"
            >
              {p.label}
            </Button>
          ))}
        </div>
      </div>
    </section>
  )
}
